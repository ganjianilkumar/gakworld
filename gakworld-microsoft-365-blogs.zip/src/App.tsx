import React, { useState, useEffect } from 'react';
import { Search, GraduationCap, Users, Bookmark, Sparkles, Filter, RefreshCcw, CheckCircle2 } from 'lucide-react';
import { BLOG_POSTS, FEATURED_RESOURCES, MICROSOFT_UPDATES } from './data/blogs';
import { BlogPost, CategoryType, AudienceType } from './types';
import Header from './components/Header';
import BlogCard, { CATEGORY_COLORS } from './components/BlogCard';
import BlogModal from './components/BlogModal';
import FeaturedResources from './components/FeaturedResources';
import RecentUpdates from './components/RecentUpdates';
import TutorialSimulator from './components/TutorialSimulator';
import PromptsSubpage from './components/PromptsSubpage';
import TutorialsSubpage from './components/TutorialsSubpage';

export default function App() {
  const [currentTab, setTab] = useState<'blogs' | 'prompts' | 'viral-tutorials' | 'simulations'>('blogs');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedCategory, setSelectedCategory] = useState<CategoryType | 'all'>('all');
  const [selectedAudience, setSelectedAudience] = useState<AudienceType | 'all'>('all');
  const [bookmarkedPostIds, setBookmarkedPostIds] = useState<string[]>([]);
  const [activePost, setActivePost] = useState<BlogPost | null>(null);
  const [showBookmarksOnly, setShowBookmarksOnly] = useState<boolean>(false);
  
  // Newsletter state
  const [newsletterEmail, setNewsletterEmail] = useState<string>('');
  const [newsletterSubscribed, setNewsletterSubscribed] = useState<boolean>(false);

  // Load bookmarks on mount
  useEffect(() => {
    const saved = localStorage.getItem('gak_m365_bookmarks');
    if (saved) {
      try {
        setBookmarkedPostIds(JSON.parse(saved));
      } catch (e) {
        console.error('Failed to parse bookmarks', e);
      }
    }
  }, []);

  // Save bookmarks
  const saveBookmarks = (ids: string[]) => {
    setBookmarkedPostIds(ids);
    localStorage.setItem('gak_m365_bookmarks', JSON.stringify(ids));
  };

  const handleBookmarkToggle = (postId: string, e?: React.MouseEvent) => {
    if (e) {
      e.stopPropagation();
    }
    const isBookmarked = bookmarkedPostIds.includes(postId);
    const updated = isBookmarked
      ? bookmarkedPostIds.filter((id) => id !== postId)
      : [...bookmarkedPostIds, postId];
    saveBookmarks(updated);
  };

  const handleResetFilters = () => {
    setSearchQuery('');
    setSelectedCategory('all');
    setSelectedAudience('all');
    setShowBookmarksOnly(false);
  };

  const toggleBookmarksOnly = () => {
    setShowBookmarksOnly(prev => !prev);
    if (!showBookmarksOnly) {
      setTab('blogs'); // Ensure we are on blogs tab to see bookmarks
    }
  };

  // Filter Blog Posts
  const filteredPosts = BLOG_POSTS.filter((post) => {
    // Bookmark filter
    if (showBookmarksOnly && !bookmarkedPostIds.includes(post.id)) {
      return false;
    }
    // Category filter
    if (selectedCategory !== 'all' && post.category !== selectedCategory) {
      return false;
    }
    // Audience filter
    if (selectedAudience !== 'all' && post.audience !== selectedAudience) {
      return false;
    }
    // Search filter
    if (searchQuery.trim() !== '') {
      const query = searchQuery.toLowerCase();
      const matchTitle = post.title.toLowerCase().includes(query);
      const matchExcerpt = post.excerpt.toLowerCase().includes(query);
      const matchTags = post.tags.some(tag => tag.toLowerCase().includes(query));
      if (!matchTitle && !matchExcerpt && !matchTags) {
        return false;
      }
    }
    return true;
  });

  const handleSubscribeNewsletter = (e: React.FormEvent) => {
    e.preventDefault();
    if (newsletterEmail.trim()) {
      setNewsletterSubscribed(true);
      setTimeout(() => {
        setNewsletterEmail('');
      }, 3000);
    }
  };

  return (
    <div className="min-h-screen bg-[#F9F7F2] text-[#121212] font-sans selection:bg-[#121212] selection:text-white flex flex-col">
      
      {/* Header component */}
      <Header
        currentTab={currentTab}
        setTab={setTab}
        bookmarksCount={bookmarkedPostIds.length}
        toggleBookmarksOnly={toggleBookmarksOnly}
        showBookmarksOnly={showBookmarksOnly}
      />

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-12">
        
        {/* HERO SECTION - BROAD_SHEET BANNER */}
        <div className="relative py-12 px-6 sm:px-12 lg:px-16 border-y-4 border-[#121212] bg-white text-center">
          <div className="max-w-4xl mx-auto space-y-6">
            <div className="inline-flex items-center space-x-2 px-3 py-1 border border-[#121212] bg-[#F0EFEC] text-[#121212] text-xs font-black uppercase tracking-widest font-mono">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Gakworld Training Portal</span>
            </div>

            <h1 className="font-serif font-black text-3xl sm:text-5xl md:text-6xl leading-none tracking-tight text-[#121212]">
              The M365 Chronicle
            </h1>
            <p className="font-mono text-xs uppercase tracking-widest text-[#555] border-t border-[#121212]/20 pt-2">
              Original tutorials, news, and step-by-step laboratories for educators and students
            </p>

            <p className="text-[#333] text-sm sm:text-base leading-relaxed max-w-2xl mx-auto font-serif italic pt-3">
              "Elevate your productivity and educational impact. Access verified Microsoft 365 blog updates, premium tutorials, lesson planners, and practical step-by-step simulations completely offline."
            </p>

            {/* Quick stats panel */}
            <div className="pt-6 grid grid-cols-2 sm:grid-cols-4 gap-4 max-w-2xl mx-auto">
              <div className="p-3 bg-[#F0EFEC] border border-[#121212] text-center">
                <p className="text-2xl font-bold font-serif text-[#121212]">6+</p>
                <p className="text-[9px] text-[#555] uppercase font-bold font-mono tracking-wider mt-0.5">M365 Apps</p>
              </div>
              <div className="p-3 bg-[#F0EFEC] border border-[#121212] text-center">
                <p className="text-2xl font-bold font-serif text-[#121212]">100%</p>
                <p className="text-[9px] text-[#555] uppercase font-bold font-mono tracking-wider mt-0.5">Free Kits</p>
              </div>
              <div className="p-3 bg-[#F0EFEC] border border-[#121212] text-center">
                <p className="text-2xl font-bold font-serif text-[#121212]">3+</p>
                <p className="text-[9px] text-[#555] uppercase font-bold font-mono tracking-wider mt-0.5">Hands-on Labs</p>
              </div>
              <div className="p-3 bg-[#F0EFEC] border border-[#121212] text-center">
                <p className="text-2xl font-bold font-serif text-[#121212]">Local</p>
                <p className="text-[9px] text-[#555] uppercase font-bold font-mono tracking-wider mt-0.5">Persistence</p>
              </div>
            </div>
          </div>
        </div>

        {/* Dynamic Navigation Tabs content */}
        {currentTab === 'blogs' && (
          /* BLOGS TAB VIEW */
          <div className="space-y-10">
            
            {/* Search & Category Filter Header */}
            <div className="bg-white p-5 sm:p-6 border-2 border-[#121212] space-y-4">
              
              <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 text-left">
                
                {/* Custom Styled Search Input */}
                <div className="relative flex-1 max-w-lg">
                  <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4.5 h-4.5 text-[#555]" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Search blogs, expert tips, or tags (e.g. Teams, Excel)..."
                    className="w-full pl-10 pr-4 py-2.5 bg-white border-2 border-[#121212] text-sm text-[#121212] outline-none transition-all font-mono placeholder-slate-400"
                    id="search-input-field"
                  />
                  {searchQuery && (
                    <button
                      onClick={() => setSearchQuery('')}
                      className="absolute right-3.5 top-1/2 -translate-y-1/2 text-xs font-black text-[#121212] hover:underline focus:outline-none"
                    >
                      CLEAR
                    </button>
                  )}
                </div>

                {/* Audience Toggles */}
                <div className="flex items-center space-x-1.5 flex-wrap gap-y-1">
                  <span className="text-xs font-black text-[#121212] uppercase tracking-wider font-mono mr-1">Audience:</span>
                  {(['all', 'educators', 'students'] as const).map((aud) => (
                    <button
                      key={aud}
                      onClick={() => setSelectedAudience(aud)}
                      className={`px-3 py-1.5 border text-xs font-bold uppercase tracking-wider transition-all ${
                        selectedAudience === aud
                          ? 'bg-[#121212] border-[#121212] text-white'
                          : 'bg-white border-[#121212]/30 text-[#121212] hover:bg-[#F0EFEC]'
                      }`}
                      id={`audience-btn-${aud}`}
                    >
                      <span>{aud === 'all' ? 'All Roles' : aud}</span>
                    </button>
                  ))}
                </div>

              </div>

              {/* Category Quick Badges */}
              <div className="pt-3 border-t border-[#121212]/10 flex flex-wrap items-center gap-2 text-left">
                <span className="text-xs font-black text-[#121212] uppercase tracking-wider font-mono mr-1">Categories:</span>
                <button
                  onClick={() => setSelectedCategory('all')}
                  className={`px-3.5 py-1.5 text-xs font-black uppercase tracking-wider border transition-all ${
                    selectedCategory === 'all'
                      ? 'bg-[#121212] border-[#121212] text-white'
                      : 'border-[#121212]/30 text-[#121212] bg-white hover:bg-[#F0EFEC]'
                  }`}
                  id="category-btn-all"
                >
                  All Apps
                </button>
                {(['teams', 'onenote', 'copilot', 'powerpoint', 'excel', 'word'] as const).map((cat) => {
                  const isSelected = selectedCategory === cat;
                  const catColor = CATEGORY_COLORS[cat];
                  return (
                    <button
                      key={cat}
                      onClick={() => setSelectedCategory(cat)}
                      className={`px-3.5 py-1.5 text-xs font-black uppercase tracking-wider border transition-all ${
                        isSelected
                          ? 'bg-[#121212] border-[#121212] text-white'
                          : 'border-[#121212]/30 text-[#121212] bg-white hover:bg-[#F0EFEC]'
                      }`}
                      id={`category-btn-${cat}`}
                    >
                      {catColor.label}
                    </button>
                  );
                })}
              </div>

            </div>

            {/* Grid Layout: Main Feed vs Sidebar updates */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
              
              {/* Left Column: Blog Feed */}
              <div className="lg:col-span-8 space-y-6">
                
                <div className="flex justify-between items-center pb-2 border-b-2 border-[#121212]">
                  <h2 className="font-serif font-bold text-2xl text-[#121212] tracking-tight">
                    {showBookmarksOnly ? 'Bookmarked Blogs' : 'M365 Article Stream'}
                  </h2>
                  <span className="text-xs font-mono font-bold text-white bg-[#121212] px-2 py-0.5 border border-[#121212]">
                    {filteredPosts.length} posts
                  </span>

                  {(searchQuery || selectedCategory !== 'all' || selectedAudience !== 'all' || showBookmarksOnly) && (
                    <button
                      onClick={handleResetFilters}
                      className="text-xs text-[#121212] hover:underline font-bold flex items-center gap-1 focus:outline-none"
                      id="reset-all-filters-btn"
                    >
                      <RefreshCcw className="w-3.5 h-3.5" />
                      <span>Reset Filters</span>
                    </button>
                  )}
                </div>

                {filteredPosts.length > 0 ? (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-6" id="blog-grid-posts">
                    {filteredPosts.map((post) => (
                      <BlogCard
                        key={post.id}
                        post={post}
                        onRead={(p) => setActivePost(p)}
                        isBookmarked={bookmarkedPostIds.includes(post.id)}
                        onBookmarkToggle={handleBookmarkToggle}
                      />
                    ))}
                  </div>
                ) : (
                  // Empty State
                  <div className="bg-white border-2 border-[#121212] p-12 text-center space-y-4" id="empty-state-container">
                    <div className="inline-flex p-4 bg-[#F0EFEC] text-[#121212] border border-[#121212]">
                      <Filter className="w-8 h-8" />
                    </div>
                    <div className="space-y-1.5 max-w-sm mx-auto">
                      <h4 className="font-serif font-bold text-[#121212] text-lg">No posts match filters</h4>
                      <p className="text-[#555] text-xs leading-relaxed font-light">
                        Try adjusting your search keywords, clearing your audience selection, or adding some bookmarks to review.
                      </p>
                    </div>
                    <button
                      onClick={handleResetFilters}
                      className="px-4 py-2 bg-[#121212] text-white text-xs font-bold uppercase tracking-wider border border-[#121212] hover:bg-black transition-all focus:outline-none"
                      id="empty-state-reset-btn"
                    >
                      Show All Blogs
                    </button>
                  </div>
                )}

              </div>

              {/* Right Column: News Sidebar & Newsletter */}
              <aside className="lg:col-span-4 space-y-6">
                
                {/* News updates list component */}
                <RecentUpdates updates={MICROSOFT_UPDATES} />

                {/* Newsletter Box - Classified Ads Style */}
                <div className="bg-[#121212] text-white p-6 border-2 border-[#121212] space-y-4">
                  <div className="space-y-1.5 text-left border-b border-white/20 pb-3">
                    <h3 className="font-serif font-bold text-xl text-[#FFB900]">Get Daily M365 Tips</h3>
                    <p className="text-xs text-slate-300 leading-relaxed font-light">
                      Stay ahead of educational updates. Join 12,000+ teachers receiving templates and productivity checklists directly.
                    </p>
                  </div>

                  {newsletterSubscribed ? (
                    <div className="p-3 bg-white/10 border border-white/10 text-xs text-[#FFB900] font-medium text-left flex items-center gap-2">
                      <CheckCircle2 className="w-4 h-4 text-green-400" />
                      <span>Thank you! Check your inbox for your prompt deck.</span>
                    </div>
                  ) : (
                    <form onSubmit={handleSubscribeNewsletter} className="space-y-2.5">
                      <input
                        type="email"
                        required
                        value={newsletterEmail}
                        onChange={(e) => setNewsletterEmail(e.target.value)}
                        placeholder="your.email@school.edu"
                        className="w-full px-4 py-2 bg-white text-[#121212] border-2 border-white text-xs placeholder-slate-400 outline-none font-mono"
                        id="newsletter-email-input"
                      />
                      <button
                        type="submit"
                        className="w-full py-2 bg-[#FFB900] text-black hover:bg-white hover:text-black font-black uppercase tracking-wider text-xs border border-transparent hover:border-white transition-all focus:outline-none"
                        id="newsletter-submit-btn"
                      >
                        Subscribe Free
                      </button>
                    </form>
                  )}
                </div>

              </aside>

            </div>

          </div>
        )}

        {currentTab === 'prompts' && (
          /* PROMPTS TAB VIEW */
          <PromptsSubpage />
        )}

        {currentTab === 'viral-tutorials' && (
          /* VIRAL TUTORIALS TAB VIEW */
          <TutorialsSubpage />
        )}

        {currentTab === 'simulations' && (
          /* INTERACTIVE LABS VIEW */
          <div className="space-y-6 text-left">
            <div>
              <h2 className="font-serif font-bold text-2xl text-[#121212] tracking-tight">
                Practical M365 Sandbox Laboratories
              </h2>
              <p className="text-xs text-[#555] font-mono uppercase tracking-widest mt-1">Practice formulas, prompt structures, and settings panels directly in our safe sandbox simulator.</p>
            </div>
            
            {/* The Simulation engine */}
            <TutorialSimulator />
          </div>
        )}

        {/* FEATURED DOWNLOADABLE RESOURCES SECTION */}
        <FeaturedResources resources={FEATURED_RESOURCES} />

      </main>

      {/* FOOTER */}
      <footer className="bg-[#F0EFEC] text-[#121212] border-t-4 border-[#121212] py-12 px-4 sm:px-6 lg:px-8 mt-16 text-left">
        <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-12 gap-8 items-center">
          
          <div className="md:col-span-5 space-y-3">
            <span className="font-serif font-bold text-xl tracking-tight text-[#121212] flex items-center gap-2">
              <span className="text-white bg-[#121212] px-2 py-0.5 text-xs font-black uppercase tracking-wider">Gak</span>
              <span>Hub</span>
            </span>
            <p className="text-xs text-[#444] leading-relaxed max-w-sm font-light">
              Gakworld M365 Hub provides comprehensive educational tutorials, expert tips, and diagnostic walkthroughs. Empowering students and teachers globally.
            </p>
          </div>

          <div className="md:col-span-4 space-y-1 text-xs">
            <p className="font-bold text-[#121212] uppercase tracking-wider text-[10px] font-mono">Quick Parent Reference:</p>
            <p className="text-[#333] font-light">
              Looking for general technical resources? Return to our parent developer hub at{' '}
              <a
                href="https://gakworld.com"
                target="_blank"
                rel="noopener noreferrer"
                className="text-[#121212] hover:underline font-bold transition-colors"
                id="parent-footer-link"
              >
                gakworld.com
              </a>
              .
            </p>
          </div>

          <div className="md:col-span-3 text-xs md:text-right space-y-1 text-[#555]">
            <p>© {new Date().getFullYear()} Gakworld M365 Hub.</p>
            <p className="font-mono text-[10px] uppercase font-bold text-[#777]">Licensed for personal & school deployment.</p>
          </div>

        </div>
      </footer>

      {/* PORTAL MODAL READER */}
      <BlogModal
        post={activePost}
        onClose={() => setActivePost(null)}
        isBookmarked={activePost ? bookmarkedPostIds.includes(activePost.id) : false}
        onBookmarkToggle={handleBookmarkToggle}
      />

    </div>
  );
}
