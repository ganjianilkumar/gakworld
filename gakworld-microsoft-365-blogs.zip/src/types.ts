export type AudienceType = 'all' | 'educators' | 'students';

export type CategoryType = 'teams' | 'onenote' | 'copilot' | 'powerpoint' | 'excel' | 'word' | 'general';

export interface BlogPost {
  id: string;
  title: string;
  excerpt: string;
  content: string; // Markdown or rich HTML-friendly text
  author: {
    name: string;
    role: string;
    avatar: string;
  };
  date: string;
  readTime: string;
  category: CategoryType;
  audience: AudienceType;
  tags: string[];
  featured: boolean;
  coverImage: string; // Elegant Tailwind background class or gradient description
  steps?: { title: string; desc: string }[]; // For tutorial blogs
}

export interface FeaturedResource {
  id: string;
  title: string;
  description: string;
  downloadUrl: string;
  type: 'template' | 'guide' | 'cheatsheet';
  size: string;
  category: CategoryType;
}

export interface MicrosoftUpdate {
  id: string;
  title: string;
  date: string;
  summary: string;
  impact: string; // 'High' | 'Medium' | 'Low'
  linkText: string;
}

export interface InteractiveStep {
  text: string;
  actionLabel: string;
  placeholder?: string;
  correctValue?: string;
  successMessage: string;
}

export interface InteractiveSimulation {
  id: string;
  title: string;
  app: 'Teams' | 'OneNote' | 'Copilot' | 'Excel';
  targetAudience: AudienceType;
  steps: InteractiveStep[];
}

export interface PromptCard {
  id: string;
  title: string;
  platform: 'ChatGPT' | 'Copilot' | 'Midjourney';
  promptText: string;
  category: string;
  description: string;
  useCase: string;
}

export interface ViralTutorial {
  id: string;
  title: string;
  platform: 'Instagram' | 'TikTok' | 'Growth Hack';
  thumbnailUrl: string;
  duration?: string;
  views?: string;
  externalLink: string;
  description: string;
  tags: string[];
}

