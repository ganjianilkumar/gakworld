import { ViralTutorial } from '../types';

export const VIRAL_TUTORIALS: ViralTutorial[] = [
  {
    id: 'tut-excel-grades-speed',
    title: 'Excel Speed Hacks: Auto-Sort Student Grades in 5 Seconds',
    platform: 'TikTok',
    thumbnailUrl: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&q=80&w=600',
    views: '450K Views',
    duration: '0:58',
    externalLink: 'https://gakworld.com/tutorials/excel-speed-hacks-auto-sort',
    description: 'The exact conditional lookup and sorting formula teachers use to identify falling student grades instantly without manual calculations. Went viral with 450k views!',
    tags: ['Excel', 'Grading Hacks', 'TikTok Education', 'Teacher Life']
  },
  {
    id: 'tut-copilot-slide-automation',
    title: 'Copilot Slide Deck Automation Secret (Zero Manual Building)',
    platform: 'Instagram',
    thumbnailUrl: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&q=80&w=600',
    views: '310K Views',
    duration: '1:12',
    externalLink: 'https://gakworld.com/tutorials/copilot-powerpoint-automation',
    description: 'Stop building PowerPoint slides manually piece-by-piece. This 1-minute Copilot trick drafts complete, high-quality outline slides from standard Microsoft Word notes.',
    tags: ['PowerPoint', 'Copilot', 'Insta Reels', 'AI Automation']
  },
  {
    id: 'tut-teacher-newsletter-growth',
    title: 'How to Build a 10K Educator Subscriber List via Free Kits',
    platform: 'Growth Hack',
    thumbnailUrl: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&q=80&w=600',
    views: '12K Readers',
    duration: '5 Min Read',
    externalLink: 'https://gakworld.com/growth-hacks/teacher-newsletter-10k',
    description: 'A deep-dive text and video growth playbook demonstrating how we bootstrapped our local school resource hub into a 10k email subscriber educational community.',
    tags: ['Growth Hacks', 'Email Marketing', 'Resource Packs', 'Gakworld Strategy']
  },
  {
    id: 'tut-onenote-audio-saving',
    title: 'OneNote Audio Comments: The grading hack saving 10 hours',
    platform: 'TikTok',
    thumbnailUrl: 'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?auto=format&fit=crop&q=80&w=600',
    views: '185K Views',
    duration: '0:45',
    externalLink: 'https://gakworld.com/tutorials/onenote-verbal-grading-saves-time',
    description: 'Skeptical about grading digital homework? Watch how dropping direct voice recordings onto student sections completely eliminates repetitive written remarks.',
    tags: ['OneNote', 'Grading Hacks', 'Time Savers', 'TikTok Classroom']
  },
  {
    id: 'tut-midjourney-ppt-backdrops',
    title: 'Midjourney Cinematic Art Backdrops for High-Impact Slides',
    platform: 'Instagram',
    thumbnailUrl: 'https://images.unsplash.com/photo-1541701494587-cb58502866ab?auto=format&fit=crop&q=80&w=600',
    views: '220K Views',
    duration: '1:05',
    externalLink: 'https://gakworld.com/tutorials/midjourney-slide-backgrounds',
    description: 'Tired of boring, flat presentation designs? Learn this custom Midjourney aspect-ratio and lighting formula to render historical or scientific illustrations.',
    tags: ['Midjourney', 'AI Art', 'Slide Design', 'Insta Reels']
  }
];
