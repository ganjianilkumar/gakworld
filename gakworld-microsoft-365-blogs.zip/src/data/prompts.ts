import { PromptCard } from '../types';

export const PROMPT_CARDS: PromptCard[] = [
  {
    id: 'prompt-socratic-lesson',
    title: 'Socratic Lesson Plan Customizer',
    platform: 'ChatGPT',
    category: 'Lesson Planning',
    description: 'Turns standard lecture topics into highly interactive Socratic dialogues where students guide their own discovery.',
    promptText: 'Act as an expert Socratic educator. Help me design a 30-minute lesson on [TOPIC] for [GRADE LEVEL]. Instead of lecturing, write a sequence of 5 guiding questions that lead students to discover the core concept of [KEY PRINCIPLE] on their own. For each question, anticipate two potential student misconceptions and provide a scaffolding follow-up question to gently redirect them without giving away the answer.',
    useCase: 'Perfect for active learning classrooms, group discussions, and student-led seminars.'
  },
  {
    id: 'prompt-homework-feedback',
    title: 'Differentiated Homework Feedback Partner',
    platform: 'ChatGPT',
    category: 'Assessment',
    description: 'Generates constructive, encouraging, and highly specific student feedback on assignments of varying quality.',
    promptText: 'You are a warm, supportive, and analytical teaching assistant. I will provide a student essay/response. Please analyze it against these criteria: [CRITERIA]. Generate three pieces of structured feedback: 1) A "Glow" highlighting a specific strength with quotes, 2) A "Grow" pointing out one major area of improvement with a constructive rewrite, and 3) A "Next Step" question to challenge them to think deeper. Keep the tone inspiring and friendly.',
    useCase: 'Saves grading time while keeping comments highly personalized and actionable.'
  },
  {
    id: 'prompt-teams-rubric',
    title: 'Teams Dynamic Rubric Builder',
    platform: 'Copilot',
    category: 'Classroom Admin',
    description: 'Creates professional multi-tier rubrics aligned with specific standards, ready to paste straight into Microsoft Teams.',
    promptText: 'Act as a curriculum designer. Create a 4-tier rubric (Excellent, Proficient, Developing, Novice) for a [PROJECT/ASSIGNMENT] in [SUBJECT]. Align it to the [STANDARD, e.g., CCSS or NGSS]. Output as a clean markdown table with columns for: Criterion Name, Points, and detailed behavioral descriptors for each of the four tiers. Focus on active, measurable verbs.',
    useCase: 'Instantly create crystal-clear, transparent grading criteria for Teams.'
  },
  {
    id: 'prompt-adaptive-reading',
    title: 'Adaptive Reading Comprehension Passage',
    platform: 'Copilot',
    category: 'Differentiation',
    description: 'Generates reading comprehension passages adapted to three distinct reading levels simultaneously.',
    promptText: 'You are an expert reading interventionist. Write a 200-word educational passage about [HISTORICAL EVENT/SCIENTIFIC CONCEPT]. Then, rewrite this exact same passage in two additional versions: one simplified for lower Lexile readers (focusing on shorter sentences and simpler vocabulary), and one advanced version for high-achieving readers (integrating sophisticated vocabulary and compound-complex syntax). Provide 3 comprehension questions that apply to all three versions.',
    useCase: 'Essential for teaching classrooms with diverse reading abilities without prepping separate topics.'
  },
  {
    id: 'prompt-sleek-flat-vectors',
    title: 'Sleek Educational Flat Vectors',
    platform: 'Midjourney',
    category: 'Graphic Assets',
    description: 'Generate professional, minimalist, high-contrast flat vector illustrations for educational slide decks or handouts.',
    promptText: 'A clean flat vector illustration of [SUBJECT, e.g., a laboratory beaker with bubbling green liquid / a vintage telescope pointing at stars], minimalist style, bold solid lines, isolated on a solid off-white background, high contrast, aesthetic pastel color scheme, 2d graphic design --ar 4:3 --v 6.0',
    useCase: 'Ditch generic clip-art for sleek, modern visuals in your presentations.'
  },
  {
    id: 'prompt-historical-cinematic',
    title: 'Historical Storyboard Cinematic Art',
    platform: 'Midjourney',
    category: 'Visual Hooks',
    description: 'Create rich, dramatic, historically accurate cinematic storyboards to introduce lessons with deep visual immersion.',
    promptText: 'A cinematic storyboard scene depicting [HISTORICAL EVENT, e.g., Galileo Galilei looking through an early telescope on an Italian balcony at night], 35mm film photograph, dramatic warm candlelight and cool moonlight, high detail, historical accuracy, rich moody atmosphere --ar 16:9 --style raw --v 6.0',
    useCase: 'Excellent for creating stunning lecture slide backdrops and lesson hooks.'
  }
];
