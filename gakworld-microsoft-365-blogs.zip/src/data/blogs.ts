import { BlogPost, FeaturedResource, MicrosoftUpdate, InteractiveSimulation } from '../types';

export const BLOG_POSTS: BlogPost[] = [
  {
    id: 'm365-teams-breakout-rooms',
    title: 'Mastering Teams Breakout Rooms: A Step-by-Step Educator Guide',
    excerpt: 'Boost student engagement by creating and managing structured, interactive breakout rooms during live remote lectures.',
    content: `
      <p class="lead">Breakout rooms in Microsoft Teams allow educators to divide students into smaller groups for focused brainstorming sessions, group projects, and peer reviews. When structured correctly, breakout rooms dramatically increase student participation and peer-to-peer learning.</p>

      <h3>Why Use Breakout Rooms?</h3>
      <p>In large virtual classrooms, quieter students often hesitate to speak. Smaller groups of 3 to 5 students create a safe environment where everyone has a voice. It fosters critical soft skills like teamwork, negotiation, and collaborative problem-solving.</p>

      <h3>Step-by-Step Implementation</h3>
      <ol>
        <li><strong>Pre-Meeting Planning:</strong> You can assign rooms automatically during the meeting, or pre-assign students to specific rooms before the meeting starts in the Teams calendar invite settings.</li>
        <li><strong>Initiate the Session:</strong> During your Teams meeting, click the <strong>Breakout Rooms</strong> icon in the top toolbar.</li>
        <li><strong>Configure Rooms:</strong> Choose the number of rooms you need (up to 50) and select whether to assign students <em>Automatically</em> (shuffles randomly) or <em>Manually</em>.</li>
        <li><strong>Set Time Limits:</strong> Click the settings gear in the breakout room panel to set a timer (e.g., 15 minutes). The rooms will close automatically and bring students back when time is up.</li>
        <li><strong>Active Facilitation:</strong> As an educator, you can join any room at any time to guide discussions, or send an announcement broadcast to all rooms simultaneously.</li>
      </ol>

      <div class="my-6 p-4 bg-blue-50 border-l-4 border-blue-500 rounded-r-md">
        <h4 class="font-bold text-blue-900">Expert Tip for Group Dynamics</h4>
        <p class="text-sm text-blue-800">Assign specific roles to students in each breakout room: a <strong>Facilitator</strong> (keeps discussion on track), a <strong>Scribe</strong> (takes collaborative notes in OneNote), and a <strong>Presenter</strong> (reports back to the main class).</p>
      </div>

      <h3>Resources for Group Work</h3>
      <p>Ensure each breakout group has a shared digital workspace. You can pre-configure a shared OneNote Class Notebook Collaboration Space section or pin a shared Word/Whiteboard file in their Microsoft Teams channel beforehand.</p>
    `,
    author: {
      name: 'Sarah Jenkins',
      role: 'M365 certified Innovative Educator',
      avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=120'
    },
    date: 'July 18, 2026',
    readTime: '6 min read',
    category: 'teams',
    audience: 'educators',
    tags: ['Microsoft Teams', 'Remote Teaching', 'Active Learning', 'Classroom Management'],
    featured: true,
    coverImage: 'bg-gradient-to-br from-indigo-500 via-purple-500 to-pink-500',
    steps: [
      { title: 'Pre-Meeting setup', desc: 'Pre-assign participants via calendar settings or set up during live meeting.' },
      { title: 'Room Allocation', desc: 'Choose between Automatic random sorting or Manual assignment.' },
      { title: 'Set Timer and Policies', desc: 'Configure automatic closure, allow students to return to main room, and set limits.' },
      { title: 'Broadcasting & Monitoring', desc: 'Send announcements across rooms and hop in to facilitate.' }
    ]
  },
  {
    id: 'm365-onenote-audio-feedback',
    title: 'Transform Student Feedback with Verbal Audio Notes in OneNote',
    excerpt: 'Ditch the red pen. Discover how speaking your feedback in OneNote Class Notebook saves grading time and boosts student comprehension.',
    content: `
      <p class="lead">Grading essays and worksheets can be a grueling process. Red-inked margins are often misunderstood or ignored. Audio feedback in OneNote offers a humanized, efficient, and deeply supportive alternative.</p>

      <h3>The Science of Audio Feedback</h3>
      <p>Research suggests that students perceive audio feedback as more detailed, supportive, and personal than written comments. Hearing their teacher's tone of voice helps them understand the constructive intent behind suggestions, reducing defensive reactions and enhancing learning.</p>

      <h3>How to Record Audio Feedback in OneNote</h3>
      <p>OneNote has built-in recording features that sync directly with the student's notebook page. Here is how simple it is:</p>
      <ol>
        <li>Open the student's notebook via the <strong>OneNote Class Notebook</strong> tab.</li>
        <li>Click anywhere on their work where you want to leave the note.</li>
        <li>Go to the <strong>Insert</strong> tab on the ribbon and click <strong>Record Audio</strong>.</li>
        <li>Speak naturally. Point out what was done exceptionally well and walk them through an area of improvement.</li>
        <li>Click <strong>Stop</strong> when done. An audio icon (.wav file) is placed precisely where your cursor was.</li>
      </ol>

      <div class="my-6 p-4 bg-purple-50 border-l-4 border-purple-500 rounded-r-md">
        <h4 class="font-bold text-purple-900">The Power of Audio-Text Syncing</h4>
        <p class="text-sm text-purple-800">In the OneNote desktop app, when you type notes *while* recording audio, OneNote links the typing to the audio timeline! When the student plays the audio, OneNote highlights the notes typed at that exact moment.</p>
      </div>

      <h3>Structuring Your Verbal Feedback</h3>
      <p>To keep audio files concise (under 2 minutes) and impactful, use the "S.E.E.D" format:</p>
      <ul>
        <li><strong>S - Support:</strong> Start with a warm greeting and highlight a major strength (e.g., "Your thesis statement is incredibly clear...").</li>
        <li><strong>E - Evidence:</strong> Read a short sentence aloud that needs attention.</li>
        <li><strong>E - Explain:</strong> Briefly explain why it can be improved.</li>
        <li><strong>D - Direction:</strong> Provide a direct actionable task for them to revise (e.g., "Review our transition words checklist before rewriting this transition...").</li>
      </ul>
    `,
    author: {
      name: 'Dr. Marcus Vance',
      role: 'Educational Technology Consultant',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=120'
    },
    date: 'July 15, 2026',
    readTime: '4 min read',
    category: 'onenote',
    audience: 'educators',
    tags: ['OneNote', 'Class Notebook', 'Student Feedback', 'Paperless Grading'],
    featured: false,
    coverImage: 'bg-gradient-to-br from-purple-600 via-indigo-600 to-blue-500'
  },
  {
    id: 'm365-copilot-lesson-plans',
    title: 'Copilot Prompting 101: Crafting Premium Lesson Plans in Seconds',
    excerpt: 'Stop staring at a blank document. Learn specific prompt structures that turn Microsoft 365 Copilot into your ultimate planning assistant.',
    content: `
      <p class="lead">AI is shifting the pedagogical landscape. Instead of spending hours building lesson plans from scratch, educators are utilizing Microsoft 365 Copilot to quickly generate interactive, customized, and differentiated curriculum ideas.</p>

      <h3>The Anatomy of an Excellent Educator Prompt</h3>
      <p>To get premium educational outputs from Copilot in Word, Teams, or Edge, you must provide context, constraints, and clear roles. Standard, lazy prompts generate generic templates. Dynamic prompts yield rich, ready-to-teach material.</p>

      <p>Use the <strong>R.A.S.C.A.</strong> Prompt Formula:</p>
      <ul>
        <li><strong>R - Role:</strong> Tell Copilot who it is (e.g., "You are an expert high school Biology teacher specializing in inquiry-based learning...").</li>
        <li><strong>A - Audience:</strong> Specify the student age and level (e.g., "The audience is 10th-grade students with diverse reading capabilities...").</li>
        <li><strong>S - Subject:</strong> The exact topic (e.g., "The topic is Cellular Respiration and how mitochondria generate ATP...").</li>
        <li><strong>C - Constraints:</strong> Clear limits (e.g., "Must fit a 50-minute class period, include 1 hands-on experiment using household items, and avoid complex chemical equations...").</li>
        <li><strong>A - Action:</strong> The output format (e.g., "Generate a lesson outline including a 5-minute bell ringer, a 15-minute group activity, and 3 differentiated exit ticket questions...").</li>
      </ul>

      <div class="my-6 p-4 bg-emerald-50 border-l-4 border-emerald-500 rounded-r-md font-mono text-sm text-emerald-900">
        <p class="font-bold mb-2">Example High-Quality Copilot Prompt:</p>
        "Act as an expert 7th-grade math teacher. Draft a 45-minute lesson plan introducing the Pythagorean Theorem. Students already know basic squaring. Include a hook using a real-world building construction example, an interactive matching puzzle as a class activity, and three exit ticket questions grouped by easy, medium, and challenging levels. Output in a beautifully organized table in Word."
      </div>

      <h3>Differentiating in Seconds</h3>
      <p>One of the greatest struggles in modern classrooms is meeting individual student needs. Copilot makes this effortless. Once you have a general lesson plan, prompt Copilot: <em>"Modify this lesson plan for a group of English Language Learners (ELL)"</em> or <em>"Provide a supplementary extension task for gifted students who finish early."</em></p>
    `,
    author: {
      name: 'Sarah Jenkins',
      role: 'M365 certified Innovative Educator',
      avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=120'
    },
    date: 'July 12, 2026',
    readTime: '8 min read',
    category: 'copilot',
    audience: 'educators',
    tags: ['Copilot', 'Artificial Intelligence', 'Lesson Planning', 'Differentiated Instruction'],
    featured: true,
    coverImage: 'bg-gradient-to-br from-teal-500 via-emerald-500 to-cyan-500',
    steps: [
      { title: 'Define the Persona', desc: 'Instruct Copilot to act as a highly specialized subject matter teacher.' },
      { title: 'Establish Constraints', desc: 'Provide timing, grade level, curriculum standards, and safety guidelines.' },
      { title: 'Incorporate Active Learning', desc: 'Ask for specific engagement techniques: think-pair-share, hands-on, or visual hooks.' },
      { title: 'Request Differentiation', desc: 'Generate adjustments for ELL, IEP, or gifted groups in one follow-up prompt.' }
    ]
  },
  {
    id: 'm365-student-onenote-study-guides',
    title: 'How to Build the Ultimate Interactive Study Guide inside OneNote',
    excerpt: 'Take control of your grades. Learn how to combine tags, search indexes, audio notes, and math tools for stress-free exam prep.',
    content: `
      <p class="lead">Studying for finals doesn't have to mean flipping through 200 pages of disorganized paper. OneNote is a digital binder that, when set up correctly, acts as a self-testing interactive study machine.</p>

      <h3>1. Create a Dedicated "Exam Prep" Notebook Section</h3>
      <p>Keep your daily class notes separate from your study summaries. Create a section tab called <strong>"Exam Prep"</strong>. Create a page for each major exam. Use OneNote's subpage feature to tuck lecture summaries beneath main topic headings.</p>

      <h3>2. Leverage the Power of OneNote Interactive Tags</h3>
      <p>Don't just highlight text. Use specific tags to build searchable index cards:</p>
      <ul>
        <li><strong>To-Do Checkboxes:</strong> Place checkboxes next to topics you need to review. Check them off as you master them.</li>
        <li><strong>Question Tags (?):</strong> Highlight concepts you are confused about and tag them. Before class, click "Find Tags" to compile a clean list of questions to ask your teacher or peers.</li>
        <li><strong>Important Star (*):</strong> Mark formulas, historical dates, or vocabulary words likely to appear on the exam.</li>
      </ul>

      <h3>3. Self-Testing with Collapsible Outline Toggles</h3>
      <p>Active recall is the most effective study method. You can build self-testing flashcards directly on a page using OneNote's indent-collapsing feature:</p>
      <ol>
        <li>Type a study question (e.g., "What are the three main types of rocks?").</li>
        <li>Directly underneath, indent (press Tab) and write the answer.</li>
        <li>Double-click the bullet or number of the main question. OneNote will collapse the text underneath it, hiding the answer!</li>
        <li>To test yourself, look at the question, guess, and double-click to reveal if you were correct.</li>
      </ol>

      <div class="my-6 p-4 bg-pink-50 border-l-4 border-pink-500 rounded-r-md">
        <h4 class="font-bold text-pink-900">Student Feature Spotlight: Math Assistant</h4>
        <p class="text-sm text-pink-800">If you are preping for a math exam, type or write an equation (e.g., 2x + 5 = 15) using digital ink, lasso select it, and click <strong>Math</strong>. OneNote will show you the step-by-step solution, draw a 2D graph, and even generate a custom 5-question practice quiz based on that exact equation format!</p>
      </div>
    `,
    author: {
      name: 'Alex Rivera',
      role: 'Student Technology Ambassador',
      avatar: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=crop&q=80&w=120'
    },
    date: 'July 10, 2026',
    readTime: '5 min read',
    category: 'onenote',
    audience: 'students',
    tags: ['OneNote', 'Study Hacks', 'Active Recall', 'Math Tools', 'Student Life'],
    featured: false,
    coverImage: 'bg-gradient-to-br from-pink-500 via-rose-500 to-orange-500'
  },
  {
    id: 'm365-powerpoint-quizzes',
    title: 'Creating Live Interactive Formative Quizzes inside PowerPoint Slides',
    excerpt: 'Turn lecture listeners into active participants. Embed real-time self-grading quiz questions into your lesson slides.',
    content: `
      <p class="lead">Static slide presentations can lead to passive zoning out. Integrating quick check-for-understanding quizzes into your slides keeps student focus locked and provides instant data on class understanding.</p>

      <h3>Method 1: Using Microsoft Forms Integration</h3>
      <p>The cleanest way to embed a live quiz is by leveraging <strong>Microsoft Forms</strong>. This takes less than 3 minutes to set up:</p>
      <ol>
        <li>Inside PowerPoint, navigate to the slide where you want the quiz to appear.</li>
        <li>Go to the <strong>Insert</strong> tab on the ribbon and click <strong>Forms</strong>.</li>
        <li>A panel will open on the right. You can either select an existing Form/Quiz you've created, or click <strong>New Quiz</strong> to build one directly inside PowerPoint.</li>
        <li>Build your multiple-choice questions. PowerPoint will embed the interactive quiz directly into the slide canvas.</li>
        <li>During the presentation, students can scan a QR code on the screen or use their personal devices to submit responses. You will see real-time chart updates displaying class answers instantly on your slide!</li>
      </ol>

      <div class="my-6 p-4 bg-orange-50 border-l-4 border-orange-500 rounded-r-md">
        <h4 class="font-bold text-orange-900">Educator Formative Assessment Power</h4>
        <p class="text-sm text-orange-800">Use this to run anonymous mid-lecture poll questions. It lets you instantly spot if 70% of the class is struggling with a concept, allowing you to re-explain it immediately rather than waiting for the final test.</p>
      </div>

      <h3>Method 2: Interactive Navigation Buttons</h3>
      <p>If students are viewing the slides independently, you can build self-checking branching quizzes using action links. Create buttons that link to a "Correct!" slide or an "Incorrect - Try Again" slide. This turns a slide deck into an interactive digital learning adventure game!</p>
    `,
    author: {
      name: 'Dr. Marcus Vance',
      role: 'Educational Technology Consultant',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=120'
    },
    date: 'July 05, 2026',
    readTime: '5 min read',
    category: 'powerpoint',
    audience: 'educators',
    tags: ['PowerPoint', 'Interactive Slides', 'Formative Assessment', 'Microsoft Forms'],
    featured: false,
    coverImage: 'bg-gradient-to-br from-orange-500 via-red-500 to-pink-600'
  },
  {
    id: 'm365-student-excel-budget',
    title: 'Excel for Students: Managing College Finances & Tracking Semester Grades',
    excerpt: 'Say goodbye to finance anxiety and grade confusion. Build a custom, automatic gradebook and budget planner.',
    content: `
      <p class="lead">Excel isn't just for corporate accountants. Learning basic formulas now will save you thousands of dollars and ensure you never experience surprise grade drops at the end of the term.</p>

      <h3>1. The Ultimate GPA & Weighted Grade Tracker</h3>
      <p>Many college classes use weighted grading (e.g., Homework is 20%, Midterms are 40%, and Finals are 40%). It's hard to calculate your true standing manually. Here is how to construct it in Excel:</p>
      <ul>
        <li><strong>Set Up Your Columns:</strong> Create columns for <em>Assignment Name</em>, <em>My Score (%)</em>, <em>Category Weight</em>, and <em>Weighted Score</em>.</li>
        <li><strong>The Math Formula:</strong> In the Weighted Score column, write the formula <code>= (Score * Weight)</code>.</li>
        <li><strong>Summing It Up:</strong> Use the <code>SUM</code> formula to total up all active weighted categories. You'll know your exact grade down to the decimal point after every assignment.</li>
      </ul>

      <div class="my-6 p-4 bg-green-50 border-l-4 border-green-500 rounded-r-md">
        <h4 class="font-bold text-green-900">Excel Hack: 'What-If' Analysis</h4>
        <p class="text-sm text-green-800">Use Excel to calculate exactly what score you need on your final exam to secure an 'A'. Simply insert dummy grades into your final exam row to see how they affect your overall weighted score!</p>
      </div>

      <h3>2. Stress-Free College Budgeting</h3>
      <p>Keep your monthly allowance, job earnings, and expenses tracked in a simple dashboard. Use <strong>Conditional Formatting</strong> to turn cells red when you exceed your set dining out budget, and green when your savings goals are successfully reached. Excel makes adulting incredibly visual and manageable.</p>
    `,
    author: {
      name: 'Alex Rivera',
      role: 'Student Technology Ambassador',
      avatar: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=crop&q=80&w=120'
    },
    date: 'July 01, 2026',
    readTime: '7 min read',
    category: 'excel',
    audience: 'students',
    tags: ['Excel Formulas', 'Budgeting for Students', 'Grade Calculator', 'Organization Tips'],
    featured: true,
    coverImage: 'bg-gradient-to-br from-green-500 via-emerald-600 to-teal-500',
    steps: [
      { title: 'Create the Layout', desc: 'Define rows for fixed costs (rent, food) and variable costs (entertainment).' },
      { title: 'Input Basic Formulas', desc: 'Use SUM, AVERAGE, and subtraction formulas to calculate monthly remaining balance.' },
      { title: 'Apply Conditional Formatting', desc: 'Make cells flash red when spending outpaces monthly budget goals.' },
      { title: 'Visualize with Charts', desc: 'Insert a quick pie chart showing your exact spending categories visually.' }
    ]
  }
];

export const FEATURED_RESOURCES: FeaturedResource[] = [
  {
    id: 'res-lesson-plan-template',
    title: 'Differentiated M365 Lesson Plan Template',
    description: 'A pre-structured Microsoft Word template configured with standard headers, active learning prompts, and quick-fill rubrics.',
    downloadUrl: '#',
    type: 'template',
    size: '1.2 MB',
    category: 'word'
  },
  {
    id: 'res-teams-cheatsheet-student',
    title: 'Teams Assignment Cheat-Sheet for Students',
    description: 'A visual, 1-page PDF explaining how to check feedback, submit revisions, access files, and coordinate group projects.',
    downloadUrl: '#',
    type: 'cheatsheet',
    size: '850 KB',
    category: 'teams'
  },
  {
    id: 'res-copilot-prompt-deck',
    title: 'Teacher Copilot Prompt Deck (50 Prompts)',
    description: 'An interactive PDF containing 50 tested, copiable prompts for generating rubrics, field trip itineraries, newsletters, and exam questions.',
    downloadUrl: '#',
    type: 'guide',
    size: '3.4 MB',
    category: 'copilot'
  },
  {
    id: 'res-onenote-digital-planner',
    title: 'Digital Homework & Life Planner for OneNote',
    description: 'Import this beautifully designed digital binder planner into OneNote. Packed with weekly trackers, grade scales, and goal-setting logs.',
    downloadUrl: '#',
    type: 'template',
    size: '12.1 MB',
    category: 'onenote'
  }
];

export const MICROSOFT_UPDATES: MicrosoftUpdate[] = [
  {
    id: 'update-copilot-class-notebook',
    title: 'Copilot in OneNote Class Notebook Rolls Out Globally',
    date: 'July 14, 2026',
    summary: 'Educators can now ask Copilot to automatically grade, review, and summarize homework directly inside students OneNote Class Notebook sections.',
    impact: 'High',
    linkText: 'Read Official Rollout Notice'
  },
  {
    id: 'update-teams-reading-progress',
    title: 'AI Reading Progress in Teams Adds Dynamic Phoneme Analysis',
    date: 'July 08, 2026',
    summary: 'Reading Progress in Teams now listens to students reading passages and isolates mispronounced phonemes, automatically generating custom targeted homework.',
    impact: 'High',
    linkText: 'Explore Reading Progress Updates'
  },
  {
    id: 'update-powerpoint-video-record',
    title: 'PowerPoint Cameo Presenter Mode Gets Real-Time Captions',
    date: 'June 28, 2026',
    summary: 'Cameo mode now supports live, translated closed-caption overlays in 40+ languages during asynchronous student video recording submissions.',
    impact: 'Medium',
    linkText: 'Learn About Presenter Cameo'
  }
];

export const INTERACTIVE_SIMULATIONS: InteractiveSimulation[] = [
  {
    id: 'sim-create-rubric-teams',
    title: 'Setting up a Grading Rubric in Microsoft Teams',
    app: 'Teams',
    targetAudience: 'educators',
    steps: [
      {
        text: 'Imagine you are setting up an assignment in Teams. Let\'s name our grading criteria. Type "Creativity & Design" in the criteria name box below:',
        actionLabel: 'Enter criteria name',
        placeholder: 'e.g. Creativity & Design',
        correctValue: 'Creativity & Design',
        successMessage: 'Excellent! Naming criteria clearly helps students understand expectations.'
      },
      {
        text: 'Now let\'s set the points value for this rubric criterion. Type "25" in the points box below:',
        actionLabel: 'Enter point value',
        placeholder: 'e.g. 25',
        correctValue: '25',
        successMessage: 'Great job! Assigning specific points turns this into a quantitative, fair grading tool.'
      },
      {
        text: 'Finally, let\'s add a description for the "Excellent" feedback tier so students know how to score full marks. Type "Exceeds all expectations with a highly polished design" below:',
        actionLabel: 'Enter criteria description',
        placeholder: 'Describe excellent work...',
        correctValue: 'Exceeds all expectations with a highly polished design',
        successMessage: 'Perfect! You have created a fully transparent grading rubric. Ready to attach to your Teams Assignment!'
      }
    ]
  },
  {
    id: 'sim-copilot-lesson-hook',
    title: 'Generating an Inquiry Lesson Hook with Copilot',
    app: 'Copilot',
    targetAudience: 'educators',
    steps: [
      {
        text: 'To get an exciting inquiry-based hook, you need to assign a role. Type "Act as a passionate middle school Science teacher" in the Prompt Box:',
        actionLabel: 'Type the role statement',
        placeholder: 'Act as a...',
        correctValue: 'Act as a passionate middle school Science teacher',
        successMessage: 'Perfect! Setting the role ensures Copilot speaks with enthusiastic, educational language.'
      },
      {
        text: 'Next, specify the topic. Type "Introduce gravity by comparing dropping a hammer versus a feather on the moon" to provide the topic detail:',
        actionLabel: 'Type the topic constraint',
        placeholder: 'e.g. Introduce gravity...',
        correctValue: 'Introduce gravity by comparing dropping a hammer versus a feather on the moon',
        successMessage: 'Spot on! Real-world educational examples make lessons deeply sticky and interactive.'
      },
      {
        text: 'Lastly, request the final deliverable style. Type "Generate 3 engaging curiosity questions for students to brainstorm in pairs" to complete the prompt:',
        actionLabel: 'Type output request',
        placeholder: 'e.g. Generate 3 engaging...',
        correctValue: 'Generate 3 engaging curiosity questions for students to brainstorm in pairs',
        successMessage: 'Awesome prompt engineered! Copilot is now ready to generate three stellar inquiry questions for your class hook!'
      }
    ]
  },
  {
    id: 'sim-excel-weighted-grades',
    title: 'Calculating Weighted Grade Totals in Microsoft Excel',
    app: 'Excel',
    targetAudience: 'students',
    steps: [
      {
        text: 'To compute a weighted score, you multiply the score by the percentage weight. In cell C2, write the formula to multiply the exam score in A2 by the weight in B2. Type "=A2*B2" in the formula bar:',
        actionLabel: 'Type formula',
        placeholder: '=A2*B2',
        correctValue: '=A2*B2',
        successMessage: 'Incredibly precise! You successfully computed the weighted midterm component.'
      },
      {
        text: 'Next, let\'s sum up the columns to find your final weighted class grade. Type the formula to sum cells C2 through C5: "=SUM(C2:C5)" in the cell formula bar:',
        actionLabel: 'Type sum formula',
        placeholder: '=SUM(C2:C5)',
        correctValue: '=SUM(C2:C5)',
        successMessage: 'Phenomenal! That formula compiles instantly, automatically displaying your overall GPA!'
      }
    ]
  }
];
