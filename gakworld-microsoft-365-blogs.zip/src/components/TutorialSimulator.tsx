import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Award, CheckCircle2, ChevronRight, HelpCircle, RefreshCw, Code, Sparkles, Send, Keyboard } from 'lucide-react';
import { INTERACTIVE_SIMULATIONS } from '../data/blogs';
import { InteractiveSimulation } from '../types';

export default function TutorialSimulator() {
  const [selectedSimId, setSelectedSimId] = useState<string>(INTERACTIVE_SIMULATIONS[0].id);
  const [currentStepIndex, setCurrentStepIndex] = useState<number>(0);
  const [inputValue, setInputValue] = useState<string>('');
  const [stepSuccess, setStepSuccess] = useState<boolean>(false);
  const [simCompleted, setSimCompleted] = useState<boolean>(false);
  const [errorFeedback, setErrorFeedback] = useState<string | null>(null);

  const activeSim = INTERACTIVE_SIMULATIONS.find(s => s.id === selectedSimId) as InteractiveSimulation;
  const activeStep = activeSim.steps[currentStepIndex];

  const handleReset = () => {
    setCurrentStepIndex(0);
    setInputValue('');
    setStepSuccess(false);
    setSimCompleted(false);
    setErrorFeedback(null);
  };

  const handleSelectSim = (id: string) => {
    setSelectedSimId(id);
    setCurrentStepIndex(0);
    setInputValue('');
    setStepSuccess(false);
    setSimCompleted(false);
    setErrorFeedback(null);
  };

  const handleAutoFill = () => {
    if (activeStep.correctValue) {
      setInputValue(activeStep.correctValue);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputValue.trim()) return;

    const userAns = inputValue.trim().toLowerCase();
    const correctAns = activeStep.correctValue?.trim().toLowerCase();

    // Check if close match or exact
    if (correctAns && (userAns === correctAns || correctAns.includes(userAns) || userAns.includes(correctAns))) {
      setStepSuccess(true);
      setErrorFeedback(null);
    } else {
      setErrorFeedback(`Hmm, that doesn't seem quite right. Try again, or click the "Auto-Fill Helper" to proceed!`);
    }
  };

  const handleNextStep = () => {
    if (currentStepIndex === activeSim.steps.length - 1) {
      setSimCompleted(true);
    } else {
      setCurrentStepIndex(prev => prev + 1);
      setInputValue('');
      setStepSuccess(false);
      setErrorFeedback(null);
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
      
      {/* Left sidebar: Select simulation */}
      <div className="lg:col-span-4 space-y-4 text-left">
        <div className="bg-white p-6 border-2 border-[#121212] space-y-4">
          <h3 className="font-serif font-bold text-[#121212] text-xl tracking-tight">
            Select Your Practice Lab
          </h3>
          <p className="text-xs text-[#555] font-light">
            Interactive, simulated environments to learn by doing. Completely safe sandbox.
          </p>
          
          <div className="space-y-2.5">
            {INTERACTIVE_SIMULATIONS.map((sim) => {
              const isSelected = sim.id === selectedSimId;
              return (
                <button
                  key={sim.id}
                  onClick={() => handleSelectSim(sim.id)}
                  className={`w-full p-4 border text-left transition-all duration-200 flex items-center justify-between ${
                    isSelected
                      ? 'bg-[#121212] border-[#121212] text-white font-bold'
                      : 'bg-[#F0EFEC] hover:bg-white border-[#121212]/30 text-[#121212]'
                  }`}
                  id={`select-sim-${sim.id}`}
                >
                  <div className="space-y-1">
                    <div className="flex items-center space-x-2">
                      <span className={`px-2 py-0.5 text-[9px] font-black uppercase tracking-wider font-mono ${
                        isSelected 
                          ? 'bg-white/20 text-white' 
                          : 'bg-[#121212] text-white'
                      }`}>
                        {sim.app}
                      </span>
                      <span className={`text-[9px] uppercase tracking-wider font-bold font-mono ${
                        isSelected ? 'text-[#F0EFEC]' : 'text-[#555]'
                      }`}>
                        {sim.targetAudience}
                      </span>
                    </div>
                    <p className="font-serif font-bold text-sm leading-snug">{sim.title}</p>
                  </div>
                  <ChevronRight className={`w-4 h-4 shrink-0 transition-transform ${isSelected ? 'translate-x-1' : ''}`} />
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Right side: Simulation Stage */}
      <div className="lg:col-span-8 bg-white border-2 border-[#121212] min-h-[500px] flex flex-col justify-between">
        
        {/* Stage Header */}
        <div className="bg-[#121212] text-white px-6 py-4 flex justify-between items-center shrink-0">
          <div className="flex items-center space-x-2.5">
            <span className="w-2.5 h-2.5 bg-red-500" />
            <span className="w-2.5 h-2.5 bg-yellow-500" />
            <span className="w-2.5 h-2.5 bg-green-500" />
            <span className="text-xs font-mono text-[#F0EFEC] ml-2">gakworld_m365_lab_sandbox://</span>
          </div>
          
          <button
            onClick={handleReset}
            className="text-xs text-[#FFB900] hover:underline font-bold flex items-center space-x-1.5 focus:outline-none"
            id="reset-lab-btn"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Restart Lab</span>
          </button>
        </div>

        {/* Core simulation content */}
        <div className="flex-1 p-6 sm:p-8 flex flex-col justify-center bg-[#F9F7F2]">
          <AnimatePresence mode="wait">
            
            {simCompleted ? (
              // Badge Screen
              <motion.div
                key="completed"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className="text-center py-8 space-y-6 max-w-md mx-auto"
                id="sim-completed-badge"
              >
                <div className="inline-flex p-5 border-2 border-[#121212] bg-[#FFB900] text-black">
                  <Award className="w-12 h-12" />
                </div>
                
                <div className="space-y-2">
                  <h3 className="font-serif font-bold text-2xl text-[#121212] leading-tight">
                    Lab Completed Successfully!
                  </h3>
                  <p className="text-sm text-[#444] font-light">
                    You have successfully completed the <strong>{activeSim.title}</strong> practical training exercise.
                  </p>
                </div>

                <div className="p-4 bg-white border border-[#121212] text-left space-y-1.5 text-xs text-[#121212] font-mono">
                  <p className="font-bold uppercase tracking-wider text-[10px]">Verifiable Badge Details:</p>
                  <p>🎓 Recipient Audience: <span className="capitalize">{activeSim.targetAudience}</span></p>
                  <p>💻 Tool Sandbox: Microsoft {activeSim.app}</p>
                  <p>📅 Timestamp: {new Date().toLocaleDateString()}</p>
                </div>

                <button
                  onClick={handleReset}
                  className="px-6 py-3 bg-[#121212] text-white font-bold uppercase tracking-wider text-xs border border-[#121212] hover:bg-[#121212]/90 transition-all focus:outline-none"
                  id="play-again-btn"
                >
                  Practice Again
                </button>
              </motion.div>
            ) : (
              // Active Step Sandbox
              <motion.div
                key={currentStepIndex}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-6"
                id={`lab-active-step-${currentStepIndex}`}
              >
                {/* Lab Progress Status */}
                <div className="flex justify-between items-center text-xs">
                  <span className="font-black text-[#121212] uppercase tracking-widest font-mono">
                    Step {currentStepIndex + 1} of {activeSim.steps.length}
                  </span>
                  <div className="flex space-x-1">
                    {activeSim.steps.map((_, idx) => (
                      <div
                        key={idx}
                        className={`h-2 w-6 border border-[#121212] transition-all duration-300 ${
                          idx === currentStepIndex
                            ? 'bg-[#121212]'
                            : idx < currentStepIndex
                              ? 'bg-green-600'
                              : 'bg-white'
                        }`}
                      />
                    ))}
                  </div>
                </div>

                {/* Simulated Tool Display */}
                <div className="border-2 border-[#121212] overflow-hidden bg-white">
                  {/* Title of mock screen */}
                  <div className="bg-[#F0EFEC] border-b border-[#121212] px-4 py-2 flex items-center justify-between text-xs font-mono text-[#121212]">
                    <span className="flex items-center gap-1.5 font-bold uppercase tracking-wide">
                      <Code className="w-3.5 h-3.5" />
                      Microsoft {activeSim.app} Workspace
                    </span>
                    <span className="text-[9px] bg-white px-2 py-0.5 border border-[#121212] font-bold uppercase">
                      Sandbox Mode
                    </span>
                  </div>

                  {/* Body depends on App */}
                  <div className="p-6">
                    {activeSim.app === 'Teams' && (
                      <div className="space-y-4">
                        <div className="p-4 bg-[#F9F7F2] border border-[#121212] space-y-3 text-sm text-left">
                          <p className="font-black text-[#121212] text-xs uppercase tracking-wider">Assignment Rubric Builder</p>
                          <div className="grid grid-cols-2 gap-4">
                            <div>
                              <label className="block text-[9px] font-bold text-[#555] uppercase">Criterion Name</label>
                              <div className="mt-1 p-2 bg-white border border-[#121212] text-[#121212] min-h-[38px] font-medium">
                                {currentStepIndex > 0 ? 'Creativity & Design' : inputValue || 'Type criteria...'}
                              </div>
                            </div>
                            <div>
                              <label className="block text-[9px] font-bold text-[#555] uppercase">Points Value</label>
                              <div className="mt-1 p-2 bg-white border border-[#121212] text-[#121212] min-h-[38px] font-mono">
                                {currentStepIndex > 1 ? '25' : (currentStepIndex === 1 ? inputValue : '')}
                              </div>
                            </div>
                          </div>
                          <div>
                            <label className="block text-[9px] font-bold text-[#555] uppercase">Excellent Tier Description</label>
                            <div className="mt-1 p-2 bg-white border border-[#121212] text-[#121212] min-h-[50px] text-xs">
                              {currentStepIndex > 2 ? 'Exceeds all expectations with a highly polished design' : (currentStepIndex === 2 ? inputValue : '')}
                            </div>
                          </div>
                        </div>
                      </div>
                    )}

                    {activeSim.app === 'Copilot' && (
                      <div className="space-y-4">
                        <div className="p-4 bg-[#121212] text-white border-2 border-[#121212] space-y-3 text-xs text-left">
                          <div className="flex justify-between items-center border-b border-white/20 pb-2">
                            <span className="font-bold text-[#00A4EF] flex items-center gap-1.5 uppercase tracking-wider text-[10px]">
                              <Sparkles className="w-3.5 h-3.5 text-[#00A4EF]" />
                              Microsoft M365 Copilot
                            </span>
                            <span className="text-[10px] text-slate-400">Word Integration</span>
                          </div>
                          
                          <div className="space-y-3 min-h-[100px] font-sans">
                            <p className="text-slate-300 leading-relaxed italic">
                              "Write a prompt to brainstorm ideas for my lesson plan..."
                            </p>
                            {currentStepIndex > 0 && (
                              <p className="text-white border-l-2 border-[#00A4EF] pl-2.5">
                                <span className="font-bold text-[#00A4EF]">Role:</span> Act as a passionate middle school Science teacher.
                              </p>
                            )}
                            {currentStepIndex > 1 && (
                              <p className="text-white border-l-2 border-[#00A4EF] pl-2.5">
                                <span className="font-bold text-[#00A4EF]">Topic:</span> Introduce gravity by comparing dropping a hammer versus a feather on the moon.
                              </p>
                            )}
                            {currentStepIndex > 2 && (
                              <p className="text-white border-l-2 border-[#00A4EF] pl-2.5">
                                <span className="font-bold text-[#00A4EF]">Action:</span> Generate 3 engaging curiosity questions for students to brainstorm in pairs.
                              </p>
                            )}
                          </div>
                        </div>
                      </div>
                    )}

                    {activeSim.app === 'Excel' && (
                      <div className="space-y-4">
                        <div className="bg-white border border-[#121212] overflow-hidden text-xs text-left">
                          <table className="w-full border-collapse">
                            <thead>
                              <tr className="bg-[#F0EFEC] border-b border-[#121212] font-mono text-[9px] text-[#121212]">
                                <th className="p-1.5 border-r border-[#121212] w-10 text-center">Row</th>
                                <th className="p-1.5 border-r border-[#121212]">A (Score)</th>
                                <th className="p-1.5 border-r border-[#121212]">B (Weight %)</th>
                                <th className="p-1.5">C (Weighted total)</th>
                              </tr>
                            </thead>
                            <tbody>
                              <tr className="border-b border-[#121212] font-mono">
                                <td className="p-1.5 border-r border-[#121212] bg-[#F0EFEC] text-center">2</td>
                                <td className="p-1.5 border-r border-[#121212]">95</td>
                                <td className="p-1.5 border-r border-[#121212]">0.40 (Midterm)</td>
                                <td className="p-1.5 bg-[#FFB900]/40 font-bold text-black">
                                  {currentStepIndex > 0 ? '38' : (currentStepIndex === 0 ? inputValue : '')}
                                </td>
                              </tr>
                              <tr className="border-b border-[#121212] font-mono">
                                <td className="p-1.5 border-r border-[#121212] bg-[#F0EFEC] text-center">3</td>
                                <td className="p-1.5 border-r border-[#121212]">90</td>
                                <td className="p-1.5 border-r border-[#121212]">0.30 (Final)</td>
                                <td className="p-1.5 font-bold">27</td>
                              </tr>
                              <tr className="border-b border-[#121212] font-mono">
                                <td className="p-1.5 border-r border-[#121212] bg-[#F0EFEC] text-center">4</td>
                                <td className="p-1.5 border-r border-[#121212]">100</td>
                                <td className="p-1.5 border-r border-[#121212]">0.20 (Homework)</td>
                                <td className="p-1.5 font-bold">20</td>
                              </tr>
                              <tr className="border-b border-[#121212] font-mono">
                                <td className="p-1.5 border-r border-[#121212] bg-[#F0EFEC] text-center">5</td>
                                <td className="p-1.5 border-r border-[#121212]">80</td>
                                <td className="p-1.5 border-r border-[#121212]">0.10 (Quiz)</td>
                                <td className="p-1.5 font-bold">8</td>
                              </tr>
                              <tr className="bg-[#F0EFEC] font-mono border-t border-[#121212]">
                                <td className="p-1.5 border-r border-[#121212] text-center font-bold">6</td>
                                <td className="p-1.5 border-r border-[#121212] font-bold" colSpan={2}>GPA Weighted Grade Total:</td>
                                <td className="p-1.5 bg-green-100 text-green-950 font-extrabold border-l border-[#121212]">
                                  {currentStepIndex > 1 ? '93' : (currentStepIndex === 1 ? inputValue : '')}
                                </td>
                              </tr>
                            </tbody>
                          </table>
                        </div>
                      </div>
                    )}
                  </div>
                </div>

                {/* Instruction Prompt & Input Form */}
                <div className="space-y-4">
                  <div className="flex gap-3 text-left">
                    <HelpCircle className="w-5 h-5 text-[#121212] shrink-0 mt-0.5" />
                    <div>
                      <p className="font-bold text-[#121212] text-sm">Instruction Prompt:</p>
                      <p className="text-[#444] text-sm leading-relaxed mt-1 font-light">
                        {activeStep.text}
                      </p>
                    </div>
                  </div>

                  {stepSuccess ? (
                    // Success state
                    <motion.div
                      initial={{ scale: 0.95, opacity: 0 }}
                      animate={{ scale: 1, opacity: 1 }}
                      className="p-4 bg-green-50 border border-green-600 space-y-3 text-left"
                    >
                      <p className="text-green-950 font-bold text-sm flex items-center gap-1.5">
                        <CheckCircle2 className="w-5 h-5 text-green-600" />
                        Correct!
                      </p>
                      <p className="text-green-800 text-xs leading-relaxed font-light">
                        {activeStep.successMessage}
                      </p>
                      <button
                        onClick={handleNextStep}
                        className="px-4 py-2 bg-[#121212] hover:bg-black text-white font-bold uppercase tracking-wider text-xs transition-all flex items-center space-x-1.5 focus:outline-none"
                        id="next-step-btn"
                      >
                        <span>Continue Lab</span>
                        <ChevronRight className="w-4 h-4" />
                      </button>
                    </motion.div>
                  ) : (
                    // Input Form
                    <form onSubmit={handleSubmit} className="space-y-3">
                      <div className="flex gap-2">
                        <input
                          type="text"
                          value={inputValue}
                          onChange={(e) => setInputValue(e.target.value)}
                          placeholder={activeStep.placeholder}
                          className="flex-1 px-4 py-3 border-2 border-[#121212] text-sm focus:outline-none bg-white text-[#121212] font-mono"
                          id="lab-text-input"
                        />
                        <button
                          type="submit"
                          className="px-5 py-3 bg-[#121212] hover:bg-black text-white font-bold uppercase tracking-wider text-xs flex items-center space-x-1.5 transition-all focus:outline-none border border-[#121212]"
                          id="submit-input-btn"
                        >
                          <Send className="w-4 h-4" />
                          <span className="hidden sm:inline">Submit</span>
                        </button>
                      </div>

                      {errorFeedback && (
                        <p className="text-red-700 text-xs text-left font-bold animate-shake" id="error-feedback-line">
                          {errorFeedback}
                        </p>
                      )}

                      {/* Helpers */}
                      <div className="flex flex-wrap items-center justify-between gap-2 pt-2 text-xs">
                        <button
                          type="button"
                          onClick={handleAutoFill}
                          className="text-[#121212] hover:underline font-bold flex items-center gap-1 focus:outline-none"
                          id="autofill-helper-btn"
                        >
                          <Keyboard className="w-4 h-4" />
                          <span>Autofill Helper (Quick Solve)</span>
                        </button>
                        <span className="text-[#555] font-mono">
                          Answer: "{activeStep.correctValue}"
                        </span>
                      </div>
                    </form>
                  )}
                </div>

              </motion.div>
            )}

          </AnimatePresence>
        </div>

        {/* Stage Footer */}
        <div className="bg-[#F0EFEC] border-t border-[#121212] px-6 py-3 shrink-0 flex justify-between items-center text-[10px] text-[#555] font-mono">
          <span>Targeting: {activeSim.app} v2026.1</span>
          <span>Security: Secured Gakworld Token</span>
        </div>

      </div>

    </div>
  );
}
