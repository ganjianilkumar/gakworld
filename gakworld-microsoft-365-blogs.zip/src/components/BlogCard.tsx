import React from 'react';
import { motion } from 'motion/react';
import { Bookmark, Clock, GraduationCap, Users, Play } from 'lucide-react';
import { BlogPost, CategoryType } from '../types';

interface BlogCardProps {
  key?: string;
  post: BlogPost;
  onRead: (post: BlogPost) => void;
  isBookmarked: boolean;
  onBookmarkToggle: (postId: string, e?: React.MouseEvent) => void;
}

export const CATEGORY_COLORS: Record<CategoryType, { bg: string; text: string; label: string }> = {
  teams: { bg: 'bg-[#0078D4]', text: 'text-white', label: 'Teams' },
  onenote: { bg: 'bg-[#80397B]', text: 'text-white', label: 'OneNote' },
  copilot: { bg: 'bg-[#00A4EF]', text: 'text-white', label: 'Copilot AI' },
  powerpoint: { bg: 'bg-[#D83B01]', text: 'text-white', label: 'PowerPoint' },
  excel: { bg: 'bg-[#217346]', text: 'text-white', label: 'Excel' },
  word: { bg: 'bg-[#0078D4]', text: 'text-white', label: 'Word' },
  general: { bg: 'bg-[#121212]', text: 'text-white', label: 'General' }
};

export default function BlogCard({ post, onRead, isBookmarked, onBookmarkToggle }: BlogCardProps) {
  const catStyles = CATEGORY_COLORS[post.category] || CATEGORY_COLORS.general;

  return (
    <motion.article
      layout
      initial={{ opacity: 0, y: 15 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -15 }}
      transition={{ duration: 0.35 }}
      className="group relative flex flex-col bg-white border-2 border-[#121212] overflow-hidden transition-all duration-300 hover:-translate-y-1 hover:shadow-[5px_5px_0px_0px_#121212]"
      id={`blog-card-${post.id}`}
    >
      {/* Cover with Solid Borders */}
      <div className={`h-40 ${post.coverImage} relative overflow-hidden flex items-end p-4 border-b border-[#121212]`}>
        <div className="absolute inset-0 bg-grid-white/[0.05] bg-[size:16px_16px] pointer-events-none" />
        <div className="absolute inset-0 bg-gradient-to-t from-slate-900/50 via-transparent to-transparent pointer-events-none" />

        <div className="relative z-10 flex flex-wrap gap-2 w-full justify-between items-center">
          {/* Target Audience Badge */}
          <span className={`inline-flex items-center px-2 py-0.5 text-[10px] font-black uppercase tracking-wider border border-white text-white bg-black/60 backdrop-blur-sm`}>
            {post.audience === 'educators' ? (
              <GraduationCap className="w-3.5 h-3.5 mr-1" />
            ) : (
              <Users className="w-3.5 h-3.5 mr-1" />
            )}
            {post.audience === 'educators' ? 'Educators' : 'Students'}
          </span>

          {/* Read Time */}
          <span className="inline-flex items-center px-2 py-0.5 text-[10px] font-mono font-bold bg-[#121212] text-white">
            <Clock className="w-3 h-3 mr-1" />
            {post.readTime}
          </span>
        </div>

        {/* Floating Bookmark Button */}
        <button
          onClick={(e) => onBookmarkToggle(post.id, e)}
          className={`absolute top-4 right-4 z-10 w-8 h-8 border border-[#121212] flex items-center justify-center transition-all ${
            isBookmarked
              ? 'bg-red-600 text-white'
              : 'bg-white/90 hover:bg-white text-[#121212]'
          }`}
          id={`bookmark-btn-${post.id}`}
          title={isBookmarked ? 'Remove from bookmarks' : 'Bookmark this article'}
        >
          <Bookmark className={`w-3.5 h-3.5 ${isBookmarked ? 'fill-white' : ''}`} />
        </button>
      </div>

      {/* Content Area */}
      <div className="flex-1 p-6 flex flex-col justify-between">
        <div>
          {/* Category Tag */}
          <span className={`inline-block ${catStyles.bg} ${catStyles.text} text-[10px] font-black px-2 py-0.5 uppercase tracking-widest`}>
            {catStyles.label}
          </span>

          {/* Blog Title - Georgia Serif */}
          <h3 className="font-serif font-bold text-xl text-[#121212] leading-snug tracking-tight mt-3">
            <button onClick={() => onRead(post)} className="text-left focus:outline-none hover:underline" id={`read-title-btn-${post.id}`}>
              {post.title}
            </button>
          </h3>

          {/* Excerpt */}
          <p className="text-[#444] text-sm mt-2 line-clamp-3 leading-relaxed font-light">
            {post.excerpt}
          </p>
        </div>

        {/* Footer / Author Block */}
        <div className="mt-6 pt-5 border-t border-[#121212] flex justify-between items-center">
          <div className="flex items-center space-x-3">
            <img
              src={post.author.avatar}
              alt={post.author.name}
              className="w-9 h-9 border border-[#121212] object-cover"
              referrerPolicy="no-referrer"
            />
            <div className="text-left">
              <p className="text-xs font-black text-[#121212] leading-none uppercase tracking-wide">{post.author.name}</p>
              <p className="text-[10px] text-[#555] font-mono mt-1 leading-none">{post.author.role}</p>
            </div>
          </div>

          <button
            onClick={() => onRead(post)}
            className="flex items-center justify-center gap-1 text-xs font-black uppercase tracking-widest border border-[#121212] px-3 py-1.5 bg-white text-[#121212] hover:bg-[#121212] hover:text-white transition-all duration-150"
            id={`read-more-btn-${post.id}`}
          >
            <span>Learn</span>
            {post.steps ? (
              <span className="flex items-center justify-center bg-[#FFB900] text-black text-[9px] px-1 font-mono font-black ml-1">
                LAB
              </span>
            ) : (
              <Play className="w-3 h-3 ml-0.5" />
            )}
          </button>
        </div>
      </div>
    </motion.article>
  );
}
