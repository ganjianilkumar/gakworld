import React, { useState } from 'react';
import { Download, FileText, BookOpen, Zap, CheckCircle2 } from 'lucide-react';
import { FeaturedResource } from '../types';

interface FeaturedResourcesProps {
  resources: FeaturedResource[];
}

export default function FeaturedResources({ resources }: FeaturedResourcesProps) {
  const [downloadingId, setDownloadingId] = useState<string | null>(null);
  const [downloadedIds, setDownloadedIds] = useState<string[]>([]);

  const handleDownload = (resId: string) => {
    setDownloadingId(resId);
    setTimeout(() => {
      setDownloadingId(null);
      setDownloadedIds((prev) => [...prev, resId]);
    }, 1500);
  };

  const getIcon = (type: 'template' | 'guide' | 'cheatsheet') => {
    switch (type) {
      case 'template':
        return <FileText className="w-5 h-5 text-[#121212]" />;
      case 'guide':
        return <BookOpen className="w-5 h-5 text-[#121212]" />;
      case 'cheatsheet':
        return <Zap className="w-5 h-5 text-[#121212]" />;
    }
  };

  return (
    <section className="space-y-6 pt-6 border-t-2 border-[#121212]">
      <div className="flex justify-between items-center text-left">
        <div>
          <h2 className="font-serif font-bold text-2xl text-[#121212] tracking-tight">
            Featured Resource Kit
          </h2>
          <p className="text-xs text-[#555] font-mono uppercase tracking-widest mt-1">Free downloadable guides, checklist charts, and planners</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {resources.map((res) => {
          const isDownloading = downloadingId === res.id;
          const isDownloaded = downloadedIds.includes(res.id);

          return (
            <div
              key={res.id}
              className="group relative bg-white p-6 border-2 border-[#121212] flex flex-col justify-between hover:-translate-y-1 hover:shadow-[4px_4px_0px_0px_#121212] transition-all duration-300"
              id={`resource-card-${res.id}`}
            >
              {/* Card Header */}
              <div className="space-y-3 text-left">
                <div className="flex justify-between items-start">
                  <div className="p-2 border border-[#121212] bg-[#F0EFEC]">
                    {getIcon(res.type)}
                  </div>
                  <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-[#555] bg-[#F0EFEC] px-1.5 py-0.5 border border-[#121212]">
                    {res.size}
                  </span>
                </div>

                <h3 className="font-serif font-bold text-lg text-[#121212] leading-snug group-hover:underline">
                  {res.title}
                </h3>
                <p className="text-[#444] text-xs leading-relaxed font-light">
                  {res.description}
                </p>
              </div>

              {/* Action Button */}
              <div className="mt-6">
                <button
                  disabled={isDownloading}
                  onClick={() => handleDownload(res.id)}
                  className={`w-full py-2 px-3 border border-[#121212] text-xs font-bold uppercase tracking-wider transition-all flex items-center justify-center space-x-2 ${
                    isDownloaded
                      ? 'bg-green-100 text-green-950 border-green-600'
                      : isDownloading
                        ? 'bg-[#F0EFEC] text-slate-500 cursor-wait'
                        : 'bg-white hover:bg-[#121212] text-[#121212] hover:text-white'
                  }`}
                  id={`resource-download-btn-${res.id}`}
                >
                  {isDownloaded ? (
                    <>
                      <CheckCircle2 className="w-4 h-4" />
                      <span>Ready in Downloads</span>
                    </>
                  ) : isDownloading ? (
                    <>
                      <span className="w-3.5 h-3.5 border-2 border-[#121212] border-t-transparent rounded-full animate-spin" />
                      <span>Bundling file...</span>
                    </>
                  ) : (
                    <>
                      <Download className="w-3.5 h-3.5" />
                      <span>Download Resource</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
}
