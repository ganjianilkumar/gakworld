import React, { useState } from 'react';
import { Play, Instagram, Video, TrendingUp, ExternalLink, Search, Flame } from 'lucide-react';
import { VIRAL_TUTORIALS } from '../data/tutorials';
import { ViralTutorial } from '../types';

export default function TutorialsSubpage() {
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedPlatform, setSelectedPlatform] = useState<'all' | 'Instagram' | 'TikTok' | 'Growth Hack'>('all');

  const filteredTutorials = VIRAL_TUTORIALS.filter((tut) => {
    // Platform filter
    if (selectedPlatform !== 'all' && tut.platform !== selectedPlatform) {
      return false;
    }
    // Search filter
    if (searchQuery.trim() !== '') {
      const query = searchQuery.toLowerCase();
      const matchTitle = tut.title.toLowerCase().includes(query);
      const matchDesc = tut.description.toLowerCase().includes(query);
      const matchTags = tut.tags.some(tag => tag.toLowerCase().includes(query));
      if (!matchTitle && !matchDesc && !matchTags) {
        return false;
      }
    }
    return true;
  });

  const getPlatformIcon = (platform: 'Instagram' | 'TikTok' | 'Growth Hack') => {
    switch (platform) {
      case 'Instagram':
        return <Instagram className="w-4 h-4 text-[#E1306C]" />;
      case 'TikTok':
        return <Video className="w-4 h-4 text-black" />;
      case 'Growth Hack':
        return <TrendingUp className="w-4 h-4 text-[#FFB900]" />;
    }
  };

  const getPlatformStyle = (platform: 'Instagram' | 'TikTok' | 'Growth Hack') => {
    switch (platform) {
      case 'Instagram':
        return 'bg-pink-50 border-pink-500 text-pink-950';
      case 'TikTok':
        return 'bg-stone-50 border-[#121212] text-stone-950';
      case 'Growth Hack':
        return 'bg-yellow-50 border-yellow-600 text-yellow-950';
    }
  };

  return (
    <div className="space-y-8 text-left">
      
      {/* Page Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="font-serif font-bold text-2xl text-[#121212] tracking-tight">
            Instagram Reels & TikTok Growth Lab
          </h2>
          <p className="text-xs text-[#555] font-mono uppercase tracking-widest mt-1">
            Short-form video tutorials, viral productivity walkthroughs, and educational audience growth hacks.
          </p>
        </div>
        
        {/* Real-time stats element */}
        <div className="inline-flex items-center gap-2 px-3 py-1.5 bg-[#121212] text-[#FFB900] border border-[#121212] text-xs font-mono font-bold">
          <Flame className="w-4 h-4 text-[#FFB900]" />
          <span>1.2M+ COMBINED VIEWS</span>
        </div>
      </div>

      {/* Control Bar: Search & Filter Tabs */}
      <div className="bg-white p-5 border-2 border-[#121212] flex flex-col md:flex-row gap-4 justify-between items-center">
        
        {/* Search */}
        <div className="relative w-full md:max-w-xs">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4.5 h-4.5 text-[#555]" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search viral strategies or tools..."
            className="w-full pl-10 pr-4 py-2 bg-white border border-[#121212] text-sm text-[#121212] outline-none font-mono"
            id="tutorial-search-input"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-[10px] font-black text-[#121212]"
            >
              CLEAR
            </button>
          )}
        </div>

        {/* Platform Toggles */}
        <div className="flex items-center space-x-1.5 flex-wrap gap-y-1 w-full md:w-auto">
          <span className="text-xs font-black text-[#121212] uppercase tracking-wider font-mono mr-1">Platform:</span>
          {(['all', 'Instagram', 'TikTok', 'Growth Hack'] as const).map((plat) => (
            <button
              key={plat}
              onClick={() => setSelectedPlatform(plat)}
              className={`px-3 py-1.5 border text-xs font-bold uppercase tracking-wider transition-all ${
                selectedPlatform === plat
                  ? 'bg-[#121212] border-[#121212] text-white font-black'
                  : 'bg-white border-[#121212]/30 text-[#121212] hover:bg-[#F0EFEC]'
              }`}
              id={`tutorial-tab-${plat}`}
            >
              {plat === 'all' ? 'All Formats' : plat}
            </button>
          ))}
        </div>

      </div>

      {/* Grid of Video / Content Cards */}
      {filteredTutorials.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6" id="tutorials-cards-grid">
          {filteredTutorials.map((tut) => {
            const platformStyle = getPlatformStyle(tut.platform);
            
            return (
              <div
                key={tut.id}
                className="bg-white border-2 border-[#121212] flex flex-col justify-between hover:shadow-[4px_4px_0px_0px_#121212] transition-all duration-200"
                id={`viral-card-${tut.id}`}
              >
                {/* Visual Thumbnail Frame */}
                <div className="relative aspect-video border-b-2 border-[#121212] overflow-hidden group/thumb bg-stone-900">
                  <img
                    src={tut.thumbnailUrl}
                    alt={tut.title}
                    className="w-full h-full object-cover opacity-80 group-hover/thumb:scale-105 transition-transform duration-500"
                    referrerPolicy="no-referrer"
                  />
                  
                  {/* Glassmorphic Play Button Overlay */}
                  <div className="absolute inset-0 flex items-center justify-center bg-[#121212]/30 opacity-90 group-hover/thumb:bg-[#121212]/45 transition-colors">
                    <div className="w-12 h-12 rounded-full bg-white border border-[#121212] flex items-center justify-center text-[#121212] group-hover/thumb:scale-110 shadow-md transition-all duration-300">
                      <Play className="w-5 h-5 fill-[#121212] translate-x-0.5 text-current" />
                    </div>
                  </div>

                  {/* Subtitle duration / reader pill on bottom-right of thumbnail */}
                  {tut.duration && (
                    <span className="absolute bottom-2.5 right-2.5 bg-black/80 text-white font-mono text-[9px] font-bold uppercase tracking-wider px-1.5 py-0.5 border border-white/20">
                      {tut.duration}
                    </span>
                  )}

                  {/* View count pill on top-left of thumbnail */}
                  {tut.views && (
                    <span className="absolute top-2.5 left-2.5 bg-[#FFB900] text-black font-mono text-[9px] font-black uppercase tracking-wider px-2 py-0.5 border border-black">
                      {tut.views}
                    </span>
                  )}
                </div>

                {/* Text Content */}
                <div className="p-5 flex-1 flex flex-col justify-between space-y-4">
                  
                  {/* Platform Header & Tags */}
                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <span className={`inline-flex items-center gap-1.5 px-2 py-0.5 border text-[10px] font-black uppercase tracking-wider ${platformStyle}`}>
                        {getPlatformIcon(tut.platform)}
                        {tut.platform}
                      </span>
                    </div>

                    <h3 className="font-serif font-bold text-base text-[#121212] leading-snug group-hover/thumb:underline">
                      {tut.title}
                    </h3>
                    
                    <p className="text-[#444] text-xs leading-relaxed font-light">
                      {tut.description}
                    </p>
                  </div>

                  {/* Tag Cloud */}
                  <div className="space-y-3 pt-3 border-t border-[#121212]/10">
                    <div className="flex flex-wrap gap-1">
                      {tut.tags.map((tag) => (
                        <span key={tag} className="text-[9px] font-mono font-bold text-[#555] bg-[#F0EFEC] border border-[#121212]/20 px-1.5 py-0.5">
                          #{tag}
                        </span>
                      ))}
                    </div>

                    {/* External Click Trigger */}
                    <a
                      href={tut.externalLink}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="w-full py-2 bg-white hover:bg-[#121212] text-[#121212] hover:text-white border border-[#121212] text-xs font-black uppercase tracking-wider transition-all flex items-center justify-center space-x-1.5"
                      id={`btn-external-tutorial-${tut.id}`}
                    >
                      <span>Get Prompts & Video</span>
                      <ExternalLink className="w-3.5 h-3.5" />
                    </a>
                  </div>

                </div>

              </div>
            );
          })}
        </div>
      ) : (
        // Empty Search State
        <div className="bg-white border-2 border-[#121212] p-12 text-center space-y-4" id="tutorials-empty-state">
          <div className="inline-flex p-4 bg-[#F0EFEC] text-[#121212] border border-[#121212]">
            <TrendingUp className="w-8 h-8" />
          </div>
          <div className="space-y-1.5 max-w-sm mx-auto">
            <h4 className="font-serif font-bold text-[#121212] text-lg">No tutorials found</h4>
            <p className="text-[#555] text-xs leading-relaxed font-light">
              We couldn't find any resources matching your search. Clear filters to continue.
            </p>
          </div>
          <button
            onClick={() => {
              setSearchQuery('');
              setSelectedPlatform('all');
            }}
            className="px-4 py-2 bg-[#121212] text-white text-xs font-bold uppercase tracking-wider border border-[#121212] hover:bg-black transition-all focus:outline-none"
          >
            Show All Formats
          </button>
        </div>
      )}

    </div>
  );
}
