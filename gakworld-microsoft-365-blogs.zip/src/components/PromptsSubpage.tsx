import React, { useState } from 'react';
import { Copy, Check, Search, Terminal, MessageSquare, Compass, Sparkles, RefreshCw } from 'lucide-react';
import { PROMPT_CARDS } from '../data/prompts';
import { PromptCard } from '../types';

export default function PromptsSubpage() {
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedPlatform, setSelectedPlatform] = useState<'all' | 'ChatGPT' | 'Copilot' | 'Midjourney'>('all');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const handleCopy = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => {
      setCopiedId(null);
    }, 2000);
  };

  const filteredPrompts = PROMPT_CARDS.filter((prompt) => {
    // Platform filter
    if (selectedPlatform !== 'all' && prompt.platform !== selectedPlatform) {
      return false;
    }
    // Search filter
    if (searchQuery.trim() !== '') {
      const query = searchQuery.toLowerCase();
      const matchTitle = prompt.title.toLowerCase().includes(query);
      const matchDesc = prompt.description.toLowerCase().includes(query);
      const matchText = prompt.promptText.toLowerCase().includes(query);
      const matchCat = prompt.category.toLowerCase().includes(query);
      if (!matchTitle && !matchDesc && !matchText && !matchCat) {
        return false;
      }
    }
    return true;
  });

  const getPlatformStyle = (platform: 'ChatGPT' | 'Copilot' | 'Midjourney') => {
    switch (platform) {
      case 'ChatGPT':
        return {
          bg: 'bg-emerald-50 text-emerald-950 border-emerald-600',
          badgeBg: 'bg-emerald-100 text-emerald-950',
          icon: <MessageSquare className="w-4 h-4 text-emerald-700" />
        };
      case 'Copilot':
        return {
          bg: 'bg-blue-50 text-blue-950 border-blue-600',
          badgeBg: 'bg-blue-100 text-blue-950',
          icon: <Sparkles className="w-4 h-4 text-blue-700" />
        };
      case 'Midjourney':
        return {
          bg: 'bg-purple-50 text-purple-950 border-purple-600',
          badgeBg: 'bg-purple-100 text-purple-950',
          icon: <Compass className="w-4 h-4 text-purple-700" />
        };
    }
  };

  return (
    <div className="space-y-8 text-left">
      
      {/* Intro Header */}
      <div>
        <h2 className="font-serif font-bold text-2xl text-[#121212] tracking-tight">
          Educator & Student AI Prompt Library
        </h2>
        <p className="text-xs text-[#555] font-mono uppercase tracking-widest mt-1">
          Hand-crafted, tested prompt architectures with copyable structures for teaching, learning, and asset generation.
        </p>
      </div>

      {/* Control Panel: Search & Platform Tabs */}
      <div className="bg-white p-5 border-2 border-[#121212] flex flex-col md:flex-row gap-4 justify-between items-center">
        
        {/* Search */}
        <div className="relative w-full md:max-w-xs">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4.5 h-4.5 text-[#555]" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search prompt templates..."
            className="w-full pl-10 pr-4 py-2 bg-white border border-[#121212] text-sm text-[#121212] outline-none font-mono"
            id="prompt-search-input"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-[10px] font-black text-[#121212]"
            >
              CLEAR
            </button>
          )}
        </div>

        {/* Platform Toggles */}
        <div className="flex items-center space-x-1.5 flex-wrap gap-y-1 w-full md:w-auto">
          <span className="text-xs font-black text-[#121212] uppercase tracking-wider font-mono mr-1">Platform:</span>
          {(['all', 'ChatGPT', 'Copilot', 'Midjourney'] as const).map((plat) => (
            <button
              key={plat}
              onClick={() => setSelectedPlatform(plat)}
              className={`px-3 py-1.5 border text-xs font-bold uppercase tracking-wider transition-all ${
                selectedPlatform === plat
                  ? 'bg-[#121212] border-[#121212] text-white font-black'
                  : 'bg-white border-[#121212]/30 text-[#121212] hover:bg-[#F0EFEC]'
              }`}
              id={`platform-tab-${plat}`}
            >
              {plat === 'all' ? 'All Engines' : plat}
            </button>
          ))}
        </div>

      </div>

      {/* Grid of Prompt Cards */}
      {filteredPrompts.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6" id="prompt-cards-grid">
          {filteredPrompts.map((prompt) => {
            const style = getPlatformStyle(prompt.platform);
            const isCopied = copiedId === prompt.id;
            
            return (
              <div
                key={prompt.id}
                className="bg-white border-2 border-[#121212] p-6 flex flex-col justify-between hover:shadow-[4px_4px_0px_0px_#121212] transition-all duration-200"
                id={`prompt-card-${prompt.id}`}
              >
                {/* Card Top Information */}
                <div className="space-y-4">
                  
                  {/* Category and Engine Tags */}
                  <div className="flex justify-between items-center">
                    <span className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 border border-[#121212] text-[10px] font-black uppercase tracking-wider ${style.badgeBg}`}>
                      {style.icon}
                      {prompt.platform}
                    </span>
                    <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-[#555] bg-[#F0EFEC] px-2 py-0.5 border border-[#121212]/30">
                      {prompt.category}
                    </span>
                  </div>

                  {/* Title & Description */}
                  <div className="space-y-1">
                    <h3 className="font-serif font-bold text-lg text-[#121212]">
                      {prompt.title}
                    </h3>
                    <p className="text-[#444] text-xs leading-relaxed font-light">
                      {prompt.description}
                    </p>
                  </div>

                  {/* Text Prompt Box */}
                  <div className="relative border-2 border-[#121212] bg-[#F9F7F2] p-4 font-mono text-[11px] leading-relaxed text-[#121212] select-all max-h-[160px] overflow-y-auto">
                    <div className="absolute top-2 right-2 bg-white px-1.5 py-0.5 text-[8px] border border-[#121212]/30 font-black text-[#555] uppercase tracking-wider pointer-events-none">
                      COPIABLE TEMPLATE
                    </div>
                    <p className="whitespace-pre-wrap pr-12 text-left">{prompt.promptText}</p>
                  </div>

                  {/* Use Case Helper */}
                  <div className="text-[11px] text-[#555] flex items-start gap-1.5 italic bg-[#F0EFEC] p-2.5 border border-[#121212]/20">
                    <span className="font-bold text-[#121212] not-italic">Use Case:</span>
                    <span>{prompt.useCase}</span>
                  </div>

                </div>

                {/* Bottom Action: Copy Prompt */}
                <div className="pt-5 mt-5 border-t border-[#121212]/10">
                  <button
                    onClick={() => handleCopy(prompt.id, prompt.promptText)}
                    className={`w-full py-2.5 border-2 border-[#121212] text-xs font-black uppercase tracking-wider transition-all flex items-center justify-center space-x-2 ${
                      isCopied
                        ? 'bg-green-100 border-green-600 text-green-950 font-bold'
                        : 'bg-white hover:bg-[#121212] text-[#121212] hover:text-white'
                    }`}
                    id={`btn-copy-prompt-${prompt.id}`}
                  >
                    {isCopied ? (
                      <>
                        <Check className="w-4 h-4 text-green-700" />
                        <span>Copied to Clipboard!</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-4 h-4" />
                        <span>Copy Prompt Template</span>
                      </>
                    )}
                  </button>
                </div>

              </div>
            );
          })}
        </div>
      ) : (
        // Empty Search State
        <div className="bg-white border-2 border-[#121212] p-12 text-center space-y-4" id="prompts-empty-state">
          <div className="inline-flex p-4 bg-[#F0EFEC] text-[#121212] border border-[#121212]">
            <Terminal className="w-8 h-8" />
          </div>
          <div className="space-y-1.5 max-w-sm mx-auto">
            <h4 className="font-serif font-bold text-[#121212] text-lg">No prompts match query</h4>
            <p className="text-[#555] text-xs leading-relaxed font-light">
              Clear your keywords or filter options to browse the entire prompt catalog.
            </p>
          </div>
          <button
            onClick={() => {
              setSearchQuery('');
              setSelectedPlatform('all');
            }}
            className="px-4 py-2 bg-[#121212] text-white text-xs font-bold uppercase tracking-wider border border-[#121212] hover:bg-black transition-all focus:outline-none"
          >
            Show All Prompts
          </button>
        </div>
      )}

    </div>
  );
}
