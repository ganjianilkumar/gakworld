import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Bookmark, BookmarkCheck, Calendar, Clock, GraduationCap, Users, Type, ChevronLeft, ChevronRight, CheckCircle2 } from 'lucide-react';
import { BlogPost } from '../types';
import { CATEGORY_COLORS } from './BlogCard';

interface BlogModalProps {
  post: BlogPost | null;
  onClose: () => void;
  isBookmarked: boolean;
  onBookmarkToggle: (postId: string) => void;
}

export default function BlogModal({ post, onClose, isBookmarked, onBookmarkToggle }: BlogModalProps) {
  const [textSize, setTextSize] = useState<'sm' | 'base' | 'lg' | 'xl'>('base');
  const [activeStep, setActiveStep] = useState<number>(0);

  // Prevent scroll background
  useEffect(() => {
    if (post) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [post]);

  if (!post) return null;

  const catStyles = CATEGORY_COLORS[post.category] || CATEGORY_COLORS.general;

  const textClassMap = {
    sm: 'text-xs leading-relaxed font-serif',
    base: 'text-sm sm:text-base leading-relaxed font-serif',
    lg: 'text-base sm:text-lg leading-relaxed font-serif',
    xl: 'text-lg sm:text-xl leading-relaxed font-serif',
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 md:p-10">
        
        {/* Backdrop */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="absolute inset-0 bg-[#121212]/80 backdrop-blur-sm"
          id="modal-backdrop"
        />

        {/* Modal Container */}
        <motion.div
          initial={{ opacity: 0, scale: 0.98, y: 15 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.98, y: 15 }}
          className="relative w-full max-w-4xl max-h-[90vh] bg-white border-2 border-[#121212] flex flex-col overflow-hidden z-10"
          id="blog-modal-content"
        >
          {/* Decorative Top Banner */}
          <div className="h-16 border-b-2 border-[#121212] bg-[#F0EFEC] flex items-center px-6 sm:px-8 shrink-0 justify-between">
            <span className="inline-flex items-center px-2 py-0.5 border border-[#121212] text-[10px] font-black uppercase tracking-wider bg-white text-[#121212]">
              {post.audience === 'educators' ? (
                <GraduationCap className="w-3.5 h-3.5 mr-1.5" />
              ) : (
                <Users className="w-3.5 h-3.5 mr-1.5" />
              )}
              {post.audience === 'educators' ? 'For Educators' : 'For Students'}
            </span>
            <div className="flex items-center space-x-2">
              <button
                onClick={() => onBookmarkToggle(post.id)}
                className="w-8 h-8 bg-white hover:bg-[#121212] text-[#121212] hover:text-white flex items-center justify-center border border-[#121212] transition-all"
                id="modal-bookmark-toggle"
                title={isBookmarked ? 'Remove Bookmark' : 'Bookmark Post'}
              >
                {isBookmarked ? (
                  <BookmarkCheck className="w-4 h-4 fill-[#121212] hover:fill-white text-current" />
                ) : (
                  <Bookmark className="w-4 h-4" />
                )}
              </button>
              <button
                onClick={onClose}
                className="w-8 h-8 bg-white hover:bg-[#121212] text-[#121212] hover:text-white flex items-center justify-center border border-[#121212] transition-all"
                id="modal-close-btn"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Scrolling Content Block */}
          <div className="flex-1 overflow-y-auto p-6 sm:p-8 md:p-10 space-y-8 bg-[#F9F7F2]">
            
            {/* Metadata and Title Header */}
            <div className="space-y-4 text-left border-b border-[#121212] pb-6">
              <div className="flex flex-wrap items-center gap-3">
                <span className={`inline-block px-2 py-0.5 text-[10px] uppercase tracking-wider font-bold border border-[#121212] ${catStyles.bg} ${catStyles.text}`}>
                  {catStyles.label}
                </span>
                <span className="text-[#555] text-xs flex items-center font-mono font-bold">
                  <Calendar className="w-3.5 h-3.5 mr-1.5" />
                  {post.date}
                </span>
                <span className="text-[#555] text-xs flex items-center font-mono font-bold">
                  <Clock className="w-3.5 h-3.5 mr-1.5" />
                  {post.readTime}
                </span>
              </div>
              <h1 className="font-serif font-bold text-2xl sm:text-3xl md:text-4xl text-[#121212] leading-tight">
                {post.title}
              </h1>
            </div>

            {/* Author Profile & Text Sizer */}
            <div className="flex flex-wrap items-center justify-between gap-4 p-4 border border-[#121212] bg-white">
              <div className="flex items-center space-x-3 text-left">
                <img
                  src={post.author.avatar}
                  alt={post.author.name}
                  className="w-10 h-10 border border-[#121212] object-cover"
                  referrerPolicy="no-referrer"
                />
                <div>
                  <p className="text-xs font-black uppercase text-[#121212]">{post.author.name}</p>
                  <p className="text-[10px] text-[#555] font-mono mt-0.5">{post.author.role}</p>
                </div>
              </div>
              
              {/* Text Sizer */}
              <div className="flex items-center space-x-1 bg-[#F0EFEC] px-2 py-1 border border-[#121212]">
                <Type className="w-3.5 h-3.5 text-[#121212]" />
                <span className="text-[10px] font-bold text-[#555] uppercase mr-1">Type:</span>
                {(['sm', 'base', 'lg', 'xl'] as const).map((sz) => (
                  <button
                    key={sz}
                    onClick={() => setTextSize(sz)}
                    className={`w-5 h-5 border text-[10px] font-black uppercase transition-all ${
                      textSize === sz 
                        ? 'bg-[#121212] text-white border-[#121212]' 
                        : 'text-[#555] bg-white border-[#121212]/30 hover:bg-[#121212] hover:text-white'
                    }`}
                  >
                    {sz === 'base' ? 'md' : sz}
                  </button>
                ))}
              </div>
            </div>

            {/* Split layout for normal blog content vs procedural tutorial steps */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
              
              {/* Left Column: Core Blog Post */}
              <div className={`lg:col-span-12 ${post.steps ? 'lg:col-span-7' : ''} space-y-6 text-left`}>
                <div 
                  className={`prose max-w-none text-[#121212] ${textClassMap[textSize]} prose-headings:font-serif prose-headings:font-bold prose-headings:text-[#121212] prose-h3:text-lg prose-h3:mt-6 prose-p:mb-4 prose-ol:list-decimal prose-ol:pl-5 prose-ul:list-disc prose-ul:pl-5`}
                  dangerouslySetInnerHTML={{ __html: post.content }}
                />

                {/* Tag Clouds */}
                <div className="pt-6 border-t border-[#121212]/30 flex flex-wrap gap-2">
                  {post.tags.map((tag) => (
                    <span key={tag} className="px-2 py-0.5 bg-white text-[#121212] border border-[#121212]/30 text-xs font-mono">
                      #{tag}
                    </span>
                  ))}
                </div>
              </div>

              {/* Right Column (Walkthrough Helper if steps exist) */}
              {post.steps && (
                <div className="lg:col-span-5 bg-[#F9F7F2] border-2 border-[#121212] p-6 space-y-4 relative text-left">
                  <div>
                    <div className="flex justify-between items-center pb-3 border-b border-[#121212]">
                      <h4 className="font-serif font-bold text-[#121212] flex items-center text-sm">
                        <GraduationCap className="w-4 h-4 mr-1.5 text-black" />
                        Practical Roadmap
                      </h4>
                      <span className="text-xs font-mono font-bold text-[#121212]">
                        {activeStep + 1} / {post.steps.length}
                      </span>
                    </div>

                    {/* Progress Dots */}
                    <div className="flex space-x-1 my-4">
                      {post.steps.map((_, idx) => (
                        <div 
                          key={idx} 
                          className={`h-1.5 border border-[#121212] transition-all duration-300 ${
                            idx === activeStep 
                              ? 'w-8 bg-[#121212]' 
                              : idx < activeStep 
                                ? 'w-2 bg-[#121212]/75' 
                                : 'w-2 bg-white'
                          }`}
                        />
                      ))}
                    </div>

                    {/* Active Step Content */}
                    <div className="min-h-[140px] flex flex-col justify-between py-2">
                      <div className="space-y-2">
                        <span className="text-[10px] font-mono font-bold text-[#121212] uppercase tracking-wider bg-[#F0EFEC] px-1.5 py-0.5 border border-[#121212]">
                          Step {activeStep + 1}: {post.steps[activeStep].title}
                        </span>
                        <p className="text-[#333] text-sm leading-relaxed font-light mt-2">
                          {post.steps[activeStep].desc}
                        </p>
                      </div>

                      {/* Navigation buttons */}
                      <div className="flex justify-between items-center mt-6">
                        <button
                          disabled={activeStep === 0}
                          onClick={() => setActiveStep(prev => prev - 1)}
                          className={`p-2 border transition-all ${
                            activeStep === 0 
                              ? 'border-slate-200 text-slate-300 cursor-not-allowed bg-white' 
                              : 'border-[#121212] text-[#121212] hover:bg-[#121212] hover:text-white bg-white'
                          }`}
                        >
                          <ChevronLeft className="w-4 h-4" />
                        </button>

                        {activeStep === post.steps.length - 1 ? (
                          <div className="flex items-center text-green-900 text-xs font-bold bg-green-100 px-3 py-1.5 border border-green-600">
                            <CheckCircle2 className="w-4 h-4 mr-1.5 text-green-700" />
                            Lab Finished!
                          </div>
                        ) : (
                          <button
                            onClick={() => setActiveStep(prev => prev + 1)}
                            className="px-4 py-2 bg-[#121212] text-white text-xs font-bold uppercase tracking-wider hover:bg-black transition-all flex items-center space-x-1"
                          >
                            <span>Next Step</span>
                            <ChevronRight className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              )}

            </div>
          </div>

          {/* Quick Disclaimer / Footer */}
          <div className="bg-[#F0EFEC] border-t-2 border-[#121212] py-4 px-8 text-center text-[#555] text-[10px] font-mono shrink-0">
            Gakworld M365 Blog Reader is a dedicated sandbox of gakworld.com featuring original training tutorials.
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
