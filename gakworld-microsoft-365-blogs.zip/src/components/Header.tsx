import React from 'react';
import { BookOpen, Bookmark, ExternalLink, Award, Terminal, Video } from 'lucide-react';

interface HeaderProps {
  currentTab: 'blogs' | 'prompts' | 'viral-tutorials' | 'simulations';
  setTab: (tab: 'blogs' | 'prompts' | 'viral-tutorials' | 'simulations') => void;
  bookmarksCount: number;
  toggleBookmarksOnly: () => void;
  showBookmarksOnly: boolean;
}

export default function Header({
  currentTab,
  setTab,
  bookmarksCount,
  toggleBookmarksOnly,
  showBookmarksOnly
}: HeaderProps) {
  return (
    <header className="sticky top-0 z-50 bg-[#FFFFFF] border-b-2 border-[#121212]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row justify-between items-center md:h-20 py-4 md:py-0 gap-4">
          
          {/* Brand Logo & Back to Parent */}
          <div className="flex items-center space-x-3 w-full md:w-auto justify-between md:justify-start">
            <div className="flex items-center space-x-3">
              <a 
                href="https://gakworld.com" 
                target="_blank" 
                rel="noopener noreferrer"
                className="group flex items-center space-x-2 px-3 py-1.5 border border-[#121212] bg-[#F0EFEC] hover:bg-[#121212] text-[#121212] hover:text-white text-xs font-bold uppercase tracking-wider transition-all"
                id="back-to-parent-btn"
              >
                <span>gakworld.com</span>
                <ExternalLink className="w-3.5 h-3.5 opacity-70 group-hover:opacity-100 transition-opacity" />
              </a>
              <div className="h-6 w-[1px] bg-[#121212] hidden sm:block"></div>
              <div className="flex flex-col text-left">
                <span className="font-display font-black text-lg tracking-tight text-[#121212] flex items-center gap-1.5">
                  <span className="bg-[#121212] text-white px-2 py-0.5 text-xs font-black uppercase tracking-tighter">Gak</span>
                  <span className="font-serif italic font-bold">M365 Hub</span>
                </span>
                <span className="text-[10px] text-[#555] font-mono tracking-widest uppercase">Microsoft 365 Education Blogs</span>
              </div>
            </div>

            {/* Mobile Bookmarks (Visible only on mobile inside the logo row) */}
            <div className="md:hidden">
              <button
                onClick={toggleBookmarksOnly}
                className={`relative p-2 text-xs font-bold uppercase tracking-wider border transition-all flex items-center space-x-1.5 ${
                  showBookmarksOnly
                    ? 'bg-red-50 border-red-600 text-red-700'
                    : 'border-[#121212] text-[#121212] bg-white hover:bg-[#F0EFEC]'
                }`}
                title="View bookmarked blogs"
              >
                <Bookmark className={`w-4 h-4 ${showBookmarksOnly ? 'fill-red-600 text-red-600' : 'text-[#121212]'}`} />
                {bookmarksCount > 0 && (
                  <span className="flex items-center justify-center w-4 h-4 font-mono text-[10px] font-bold bg-[#121212] text-white">
                    {bookmarksCount}
                  </span>
                )}
              </button>
            </div>
          </div>

          {/* Core Tab Toggles */}
          <nav className="flex flex-wrap items-center justify-center gap-1.5" id="navigation-tabs">
            <button
              onClick={() => {
                setTab('blogs');
                if (showBookmarksOnly) toggleBookmarksOnly();
              }}
              className={`px-3 py-2 border text-[11px] font-bold uppercase tracking-wider transition-all flex items-center space-x-1.5 ${
                currentTab === 'blogs' && !showBookmarksOnly
                  ? 'bg-[#121212] border-[#121212] text-white font-black'
                  : 'border-transparent text-[#555] hover:border-[#121212] hover:text-[#121212]'
              }`}
              id="tab-blogs-trigger"
            >
              <BookOpen className="w-3.5 h-3.5" />
              <span>Blogs</span>
            </button>
            <button
              onClick={() => {
                setTab('prompts');
                if (showBookmarksOnly) toggleBookmarksOnly();
              }}
              className={`px-3 py-2 border text-[11px] font-bold uppercase tracking-wider transition-all flex items-center space-x-1.5 ${
                currentTab === 'prompts' && !showBookmarksOnly
                  ? 'bg-[#121212] border-[#121212] text-white font-black'
                  : 'border-transparent text-[#555] hover:border-[#121212] hover:text-[#121212]'
              }`}
              id="tab-prompts-trigger"
            >
              <Terminal className="w-3.5 h-3.5" />
              <span>AI Prompts</span>
            </button>
            <button
              onClick={() => {
                setTab('viral-tutorials');
                if (showBookmarksOnly) toggleBookmarksOnly();
              }}
              className={`px-3 py-2 border text-[11px] font-bold uppercase tracking-wider transition-all flex items-center space-x-1.5 ${
                currentTab === 'viral-tutorials' && !showBookmarksOnly
                  ? 'bg-[#121212] border-[#121212] text-white font-black'
                  : 'border-transparent text-[#555] hover:border-[#121212] hover:text-[#121212]'
              }`}
              id="tab-viral-tutorials-trigger"
            >
              <Video className="w-3.5 h-3.5" />
              <span>Viral Tutorials</span>
            </button>
            <button
              onClick={() => {
                setTab('simulations');
                if (showBookmarksOnly) toggleBookmarksOnly();
              }}
              className={`px-3 py-2 border text-[11px] font-bold uppercase tracking-wider transition-all flex items-center space-x-1.5 ${
                currentTab === 'simulations' && !showBookmarksOnly
                  ? 'bg-[#121212] border-[#121212] text-white font-black'
                  : 'border-transparent text-[#555] hover:border-[#121212] hover:text-[#121212]'
              }`}
              id="tab-simulations-trigger"
            >
              <Award className="w-3.5 h-3.5" />
              <span>Interactive Labs</span>
            </button>
          </nav>

          {/* Bookmarks Toggle (Desktop only) */}
          <div className="hidden md:flex items-center space-x-2">
            <button
              onClick={toggleBookmarksOnly}
              className={`relative px-3.5 py-2 text-xs font-bold uppercase tracking-wider border transition-all flex items-center space-x-2 ${
                showBookmarksOnly
                  ? 'bg-red-50 border-red-600 text-red-700'
                  : 'border-[#121212] text-[#121212] bg-white hover:bg-[#F0EFEC]'
              }`}
              id="bookmarks-toggle-btn"
              title="View bookmarked blogs"
            >
              <Bookmark className={`w-4 h-4 ${showBookmarksOnly ? 'fill-red-600 text-red-600' : 'text-[#121212]'}`} />
              <span>Bookmarks</span>
              {bookmarksCount > 0 && (
                <span className={`flex items-center justify-center w-5 h-5 font-mono text-xs font-bold leading-none ${
                  showBookmarksOnly ? 'bg-red-600 text-white' : 'bg-[#121212] text-white'
                }`}>
                  {bookmarksCount}
                </span>
              )}
            </button>
          </div>

        </div>
      </div>
    </header>
  );
}
