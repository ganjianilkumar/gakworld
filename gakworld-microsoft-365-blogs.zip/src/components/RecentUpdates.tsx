import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Calendar, ChevronDown, ChevronUp, Bell, AlertCircle } from 'lucide-react';
import { MicrosoftUpdate } from '../types';

interface RecentUpdatesProps {
  updates: MicrosoftUpdate[];
}

export default function RecentUpdates({ updates }: RecentUpdatesProps) {
  const [expandedId, setExpandedId] = useState<string | null>(null);

  const toggleExpand = (id: string) => {
    setExpandedId((prev) => (prev === id ? null : id));
  };

  return (
    <div className="bg-[#F0EFEC] text-[#121212] border-2 border-[#121212] p-6 sm:p-8 relative overflow-hidden">
      {/* Header section - News Style */}
      <div className="relative z-10 flex items-center space-x-3 mb-8 pb-4 border-b border-[#121212]">
        <div className="p-2 border border-[#121212] bg-white text-[#121212]">
          <Bell className="w-5 h-5" />
        </div>
        <div>
          <h2 className="font-serif font-bold text-xl text-[#121212] tracking-tight">
            Recent M365 Education Updates
          </h2>
          <p className="text-[10px] text-[#555] font-mono tracking-widest uppercase mt-0.5">Live Rollout Timeline & News Feed</p>
        </div>
      </div>

      {/* Updates Timeline List */}
      <div className="relative z-10 space-y-4">
        {updates.map((update) => {
          const isExpanded = expandedId === update.id;

          return (
            <div
              key={update.id}
              className={`p-5 border transition-all duration-300 ${
                isExpanded
                  ? 'bg-white border-[#121212] shadow-[3px_3px_0px_0px_#121212]'
                  : 'bg-white/40 border-[#121212]/40 hover:bg-white hover:border-[#121212]'
              }`}
              id={`news-item-${update.id}`}
            >
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                
                {/* Left Metadata block */}
                <div className="space-y-1">
                  <div className="flex items-center space-x-2">
                    <span className="text-[10px] text-[#555] font-mono flex items-center tracking-wide">
                      <Calendar className="w-3.5 h-3.5 mr-1" />
                      {update.date}
                    </span>
                    <span className={`px-2 py-0.5 text-[9px] font-mono font-bold uppercase tracking-wider ${
                      update.impact === 'High'
                        ? 'bg-red-100 text-red-800 border border-red-300'
                        : 'bg-amber-100 text-amber-800 border border-amber-300'
                    }`}>
                      {update.impact} Impact
                    </span>
                  </div>
                  
                  <h3 className="font-serif font-bold text-base text-[#121212]">
                    {update.title}
                  </h3>
                </div>

                {/* Right trigger block */}
                <button
                  onClick={() => toggleExpand(update.id)}
                  className={`self-start sm:self-center px-3 py-1 text-[10px] font-bold uppercase tracking-wider border transition-all ${
                    isExpanded
                      ? 'bg-[#121212] border-[#121212] text-white'
                      : 'bg-white border-[#121212] text-[#121212] hover:bg-[#F0EFEC]'
                  }`}
                  id={`news-expand-btn-${update.id}`}
                >
                  <span className="mr-1">{isExpanded ? 'Collapse' : 'View'}</span>
                  {isExpanded ? <ChevronUp className="w-3 h-3 inline" /> : <ChevronDown className="w-3 h-3 inline" />}
                </button>
              </div>

              {/* Expandable summary details */}
              <AnimatePresence>
                {isExpanded && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: 'auto', opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.25 }}
                    className="overflow-hidden"
                  >
                    <div className="pt-4 mt-4 border-t border-[#121212] space-y-4">
                      <p className="text-sm text-[#444] leading-relaxed font-light">
                        {update.summary}
                      </p>
                      
                      <div className="p-3.5 bg-[#F0EFEC] border border-[#121212] flex gap-3">
                        <AlertCircle className="w-4 h-4 text-[#121212] shrink-0 mt-0.5" />
                        <div className="text-xs space-y-1 text-left">
                          <p className="font-bold text-[#121212] uppercase tracking-wider text-[10px]">Action Plan for Gakworld Readers:</p>
                          <p className="text-[#444] leading-relaxed">
                            {update.impact === 'High' 
                              ? 'This contains critical feature enhancements. Check your tenant settings or consult Microsoft Admin Center to turn on preview channels.'
                              : 'Recommended reading for educational leaders seeking to automate coursework grading workflows.'}
                          </p>
                        </div>
                      </div>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>

            </div>
          );
        })}
      </div>
    </div>
  );
}
